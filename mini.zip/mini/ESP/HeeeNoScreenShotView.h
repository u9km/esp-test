//XN开源PUBG3.2引擎源码 打包更换验证及可使用 TG；Hack_GTX 进频道等待开源和平GTX
//XN操死小辞 小处的全家
//小辞喜欢白嫖 目尊无人 小辞母亲已被操烂
//小处喜欢装逼 被刺 喷驱同时也是死妈的
//使用此源码的人都是小辞 小处他们的爹 如小辞小处使用本源码 扣东西 必全家死光



#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HeeeNoScreenShotView : UIView

@end

NS_ASSUME_NONNULL_END
