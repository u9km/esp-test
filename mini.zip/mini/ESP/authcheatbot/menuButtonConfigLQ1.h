



#ifndef menuButtonConfigLQ1_h
#define menuButtonConfigLQ1_h


#endif
#define menuButtonConfigLQ1 @""
