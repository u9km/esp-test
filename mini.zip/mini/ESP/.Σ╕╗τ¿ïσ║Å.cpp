//Imgui支持调用 {
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <cstdint>
#include <sys/uio.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <math.h>
#include <GLES3/gl3.h>
#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include "Dobby/dobby.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
//#include "无痕锁链读写.h"
#include <pthread.h>
#include <sys/socket.h>
#include <malloc.h>
#include <math.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <locale>
#include <string>
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
#include <iostream>
#include <thread>
#include <chrono>
#include "imgui/imgui.h"
#include "imgui/backends/imgui_impl_android.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "黑客/ImguiPP.h"
//}
//#include "xhook/xhook.h"

//配置文件调用 {
#include "黑客/Spoof.h"
//#include "UE4.h"
#include "Helper/fake_dlfcn.h"
#include "Helper/Includes.h"
#include "Helper/plthook.h"
#include "Helper/json.hpp"
#include "Helper/Items.h"
#include "字体.h"
#include "黑客/StrEnc.h"
#include "黑客/Tools.h"
#include "黑客/obfuscate.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"
#include "Includes/Macros.h"
#include "SDK.hpp"
#include "base64/base64.h"
#include "Engine/Canvas.h"
#include "黑客/Colors.h"
#include "黑客/Roboto_Bold.h"
#include "黑客/NIKE.h"
#include "黑客/Roboto_Medium.h"
#include "KittyMemory/MemoryPatch.h"
#include "黑客/Syscall读写.h"
#include "imgui/stb_image.cpp"
#include "配置/内存配置/内存读写.hpp"
#define STB_IMAGE_IMPLEMENTATION
//}


//游戏及配置调用{
#define targetLibName OBFUSCATE("libanort.so")
#define targetLibName OBFUSCATE("libanogs.so")
#define targetLibName OBFUSCATE("libUE4.so:bss")
#define targetLibName OBFUSCATE("libUE4.so")
#define PATCH_LIB
#define HOOK_LIB
#define STB_IMAGE_IMPLEMENTATION
using namespace SDK;
ImFont* basic = nullptr;
std::string g_Token, g_Auth;
ImFont* roboto_bold;
ImFont* roboto_medium;
using json = nlohmann::json;
uintptr_t UE4Bss;
uintptr_t UE4;
uintptr_t Self;
uintptr_t Anogs;
uintptr_t gcloud;
android_app *g_App = 0;
time_t expiredDate = 0;
ASTExtraPlayerCharacter *g_LocalPlayer = 0;
ASTExtraPlayerController *g_LocalController = 0;
ASTExtraPlayerCharacter *LockObj = 0;


char extra[32];
//#define px
#define IM_PI 3.14159265358979323846f
#define RAD2DEG(x) ((float)(x) * (float)(180.f / IM_PI))
#define DEG2RAD(x) ((float)(x) * (float)(IM_PI / 180.f))
//}

//偏移 {
#define GNames_Offset 0x771e2b4
#define GEngine_Offset 0xdc10ff0 //ULocalPlayer
#define GEngine_Offset 0xdc35fe8 //UEngine
#define GUObject_Offset 0xd8fb2a0
#define GetActorArray_Offset 0x9788858
#define Canvas_Map_Offset 0xd72e8d0
#define Process_Event_Offset 0x7981c68 //Child
#define Process_Event_Offset 0x92f5c68 //Main
#define GNativeAndroidApp_Offset 0xD66AE50
#define Actors_Offset 0xa0
#define eglSwapBuffers 0xbe6d270
#define _BYTE  uint8_t
//}


#include "封装绘图.h"


//功能调用{
FVector targetAimPos;
static int style_idx = 0;
static int a = 0;
bool bValid = false;
bool show_another_window2 = false;
bool IsVisible = true;
bool 无后;
//bool px = true;
bool 防抖;
bool 据点;
bool 追踪线;
bool 全图变色;
bool 七图;
bool 除雾;
bool 打击特效;
bool 地铁加速;
bool 快速切枪 = false;
bool 快速切枪关 = false;
bool 快速切枪开 = false;
bool 无限子弹 = false;
bool 无限子弹关 = false;
bool 无限子弹开 = false;
bool 枪械据点 = false;
bool 枪械防抖 = false;
bool 枪械无后 = false;
bool 旋转变色;
bool 准心rgb;
bool rgb;
bool 载具自控;
bool unlock;
float 旋转速度 = 20.0f;
bool 广角,射速,内存范围;
bool 自改射速;
bool 准心,骨骼,线条,武器,预警,雷达,名字,车辆,盒子,距离,血量1,血量2,忽略人机,背包等级,绘制狗子,雷达Y,雷达X;
bool 设置控件,自瞄控件,追踪控件,绘制控件,功能控件 = true,shit;
bool 追踪,配置1,配置2,忽略人坤,忽略倒地,漏打,自动开火;
bool 自动瞄准,开火,开镜,开火开镜;
float Aim_Anticipation = 1.950;
float 自瞄速度 = 2.0;
float Aim_PosZ = 0.012;
float Aim_Vehicle = 1.820;
static bool 安全 = true;
static bool 残酷 = false;
static bool is头,is脖子,is盆骨,is左锁骨,is右锁骨,is左上臂,is左小臂,is左手,is左大腿,is左小腿,is左脚,is右上臂,is右小臂,is右手,is右大腿,is右小腿,is右脚,is脊骨1,is脊骨2,is脊骨3;
//5
static int 算法 = 0;
static int 函数 = 1;
float r, g, b;
bool 头部,身体;
bool 水印;
float px;
float 雷达大小 = 90.0f;
float 广角调节 = 1.5;
float 范围 = 150.0f;
ImTextureID icon, back1,back2;
int screenWidth = 2400, screenHeight = 1080, glWidth, glHeight, gWidth, gHeight;
float density = -1;
bool initImGui = false;
//}
bool 概率子追 = false;
static float 子追命中率=0.60;
float 射速调节 =0.098;
static int ZdDq;
static int ZdMax;
static int TestDe = 0;
static int ASD;
static bool IsLaunch = false;
bool 追踪状态=true;
float Distance;

//世界地址区域{
static UEngine *GEngine = 0;
UWorld *GetWorld() {
    while (!GEngine) {
        GEngine = UObject::FindObject<UEngine>("UAEGameEngine Transient.UAEGameEngine_1"); // Auto
        sleep(1);
    }
    if (GEngine) {
        auto ViewPort = GEngine->GameViewport;

        if (ViewPort) {
            //return {};
            return ViewPort->World;
        }
    }
    return 0;
}



TNameEntryArray *GetGNames() {
    return ((TNameEntryArray *(*)()) (UE4 + GNames_Offset))();
}

TArray<AActor *> getActors() {
    auto World = GetWorld();
    if (World) {
        auto PersistentLevel = World->PersistentLevel;
        if (PersistentLevel) {
            return *(TArray<AActor *> *) ((uintptr_t) PersistentLevel + Actors_Offset);
        }
    }
    return TArray<AActor *>();
}

std::string getObjectPath(UObject *Object) {
    std::string s;
    for (auto super = Object->ClassPrivate; super; super = (UClass *) super->SuperStruct) {
        if (!s.empty())
            s += ".";
        s += super->NamePrivate.GetName();
    }
    return s;
}
//}


//死人调用{
struct sConfig {
    struct sColorsESP
    {
        float *PVisibile;
        float *PNonVis;
        float *PVLine;
        float *PVILine;
        float *BVLine;
        float *BVILine;
        float *PVBox;
        float *PVIBox;
        float *BVBox;
        float *BVIBox;
        float *PVSkeleton;
        float *PVISkeleton;
        float *BVSkeleton;
        float *BVISkeleton;
        float *Fov;
        float *Fov2;
        float *Text;
        float *Box3D;
        float *RGB;
        float *Count;
        float *TeamID;
        float *Name;
        float *WeaponId;
        float *Distance;
        float *Vehicle;
        float *Items;
    };
    sColorsESP ColorsESP{0};
    struct sOTHER {
        bool FPS;
        bool HIDEESP;
        bool EXPIRYTIME;
    };
    sOTHER OTHER{0};
};
sConfig Config{0};
//}


//获取bss模块
long GetModule(char *name) {
    char*phgsr;
    char jjjj_N[64];
    long startaddr = 0;
    char path[256],line[1024];
    bool bssOF = false,LastIsSo = false;
    strcpy(jjjj_N,name);
    phgsr = strtok(jjjj_N,":");
    name = phgsr;
    phgsr = strtok(NULL,":");
    if(phgsr)
    {
        if(strcmp(phgsr,"bss")==0)
        {
            bssOF = true;
        }
    }
    sprintf(path,"/proc/self/maps");
    FILE*p = fopen(path,"r");
    if(p)
    {
        while(fgets(line,sizeof(line),p))
        {
            if(LastIsSo)
            {
                if(strstr(line,"[anon:.bss]")!=NULL)
                {
                    sscanf(line,"%lx-%*lx",&startaddr);
                    break;
                }
                else
                {
                    LastIsSo = false;
                }
            }
            if(strstr(line,name)!=NULL)
            {
                if(!bssOF)
                {
                    sscanf(line,"%lx-%*lx",&startaddr);
                    break;
                }
                else
                {
                    LastIsSo = true;
                }
            }
        }
        fclose(p);
    }
    return startaddr;
}




#define CREATE_COLOR(r, g, b, a) new float[4] {(float)r, (float)g, (float)b, (float)a};

typedef void (*ImGuiDemoMarkerCallback)(const char* file, int line, const char* section, void* user_data);
extern ImGuiDemoMarkerCallback  GImGuiDemoMarkerCallback;
extern void* GImGuiDemoMarkerCallbackUserData;
ImGuiDemoMarkerCallback         GImGuiDemoMarkerCallback = NULL;
void* GImGuiDemoMarkerCallbackUserData = NULL;
#define IMGUI_DEMO_MARKER(section)  do { if (GImGuiDemoMarkerCallback != NULL) GImGuiDemoMarkerCallback(__FILE__, __LINE__, section, GImGuiDemoMarkerCallbackUserData); } while (0)
struct sRegion {
    uintptr_t start, end;
};

std::vector<sRegion> trapRegions;

bool isObjectInvalid(UObject *obj) {
    if (!Tools::IsPtrValid(obj)) {
        return true;
    }

    if (!Tools::IsPtrValid(obj->ClassPrivate)) {
        return true;
    }

    if (obj->InternalIndex <= 0) {
        return true;
    }

    if (obj->NamePrivate.ComparisonIndex <= 0) {
        return true;
    }

    if ((uintptr_t)(obj) % sizeof(uintptr_t) != 0x0 && (uintptr_t)(obj) % sizeof(uintptr_t) != 0x4) {
        return true;
    }

    if (std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) {
    return ((uintptr_t) obj) >= region.start && ((uintptr_t) obj) <= region.end;
    }) ||
    std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) {
        return ((uintptr_t) obj->ClassPrivate) >= region.start && ((uintptr_t) obj->ClassPrivate) <= region.end;
    })) {
        return true;
    }

    return false;
}
// ======================================================================== //

int32_t ToColor(float *col) {
    return ImGui::ColorConvertFloat4ToU32(*(ImVec4 *) (col));
}

FRotator ToRotator(FVector local, FVector target) {
    FVector rotation = UKismetMathLibrary::Subtract_VectorVector(local, target);

    float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);

    FRotator newViewAngle = {0};
    newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Roll = (float) 0.f;

    if (rotation.X >= 0.f)
        newViewAngle.Yaw += 180.0f;

    return newViewAngle;
}
void AimAngle(FRotator &angles) {
    if (angles.Pitch > 180)
        angles.Pitch -= 360;
    if (angles.Pitch < -180)
        angles.Pitch += 360;

    if (angles.Pitch < -75.f)
        angles.Pitch = -75.f;
    else if (angles.Pitch > 75.f)
        angles.Pitch = 75.f;

    while (angles.Yaw < -180.0f)
        angles.Yaw += 360.0f;
    while (angles.Yaw > 180.0f)
        angles.Yaw -= 360.0f;
}
FRotator ClampAngles(FRotator inRot) {
    FRotator outRot = inRot;
    if (outRot.Pitch > 180)
        outRot.Pitch -= 360;
    if (outRot.Pitch < -180)
        outRot.Pitch += 360;

    if (outRot.Pitch < -75.f)
        outRot.Pitch = -75.f;
    else if (outRot.Pitch > 75.f)
        outRot.Pitch = 75.f;

    while (outRot.Yaw < -180.0f)
        outRot.Yaw += 360.0f;
    while (outRot.Yaw > 180.0f)
        outRot.Yaw -= 360.0f;
    return outRot;
}



#define W2S(w, s) UGameplayStatics::ProjectWorldToScreen(g_LocalController, w, true, s)
/////////===////


bool Fov(int x, int y) {
    int circle_x = glWidth / 2;
    int circle_y = glHeight / 2;
    int rad =范围;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

bool isInsideFov(int x, int y) {
    if (!追踪)
        return true;

    int circle_x = glWidth / 2;
    int circle_y = glHeight / 2;
    int rad = 范围;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}
auto NIKE_Aim_Thread() {
    ASTExtraPlayerCharacter *result = 0;
    auto GWorld = GetWorld();
    if (GWorld)	{
        auto localPlayer = g_LocalPlayer;
        auto localController = g_LocalController;
        auto Actors = getActors();
        if (localPlayer) {
            for (int i = 0; i < Actors.Num(); i++) {
                auto Actor = Actors[i];
                if (isObjectInvalid(Actor))
                    continue;
                if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                    auto Player = (ASTExtraPlayerCharacter *) Actors[i];
                    auto LootBox = (APickUpListWrapperActor *) Actor;
                    float max = std::numeric_limits<float>::infinity();

                    if (Player->PlayerKey == localPlayer->PlayerKey)
                        continue;

                    if (Player->TeamID == localPlayer->TeamID)
                        continue;

                    if (Player->bDead)
                        continue;



                    if (忽略倒地) {
                        if (Player->Health == 0.0f)
                            continue;
                    }
/*if (地铁加速) {
writefloat(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x88, 99999); //1
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x1B8, 150); //45
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x550, 0); //240
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x200, 0); //60000
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x284, 0); //7500
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x21C, 99999); //2048
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x208, 99999); //8192
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0xB58, 888); //670
					writefloat(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x1080, 4); //1
					writefloat(UE4 + 0x52AEC14,8.95671814e-21); //xa加速
					}else{
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x1BC, 443); //443
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x1B4, 1); //1
					writefloat(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x88, 99999); //1
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x1B8, 45); //45
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x550, 240); //240
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x200, 60000); //60000
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x284, 7500); //7500
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x21C, 2048); //2048
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x208, 8192); //8192
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0xB58, 670); //670
					writefloat(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x1080, 1); //1
					writefloat(UE4 + 0x52AEC14,1418629120); //xa加速
					writedword(UE4 + 0x949116C,-117286283); //xa锁地皮
}*/

/*if (七图) {

writedword(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x88, 0); //灵魂
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x1B0) + 0x1c0, 76795); //x
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x1B0) + 0x1c4, 153070); //y
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x1B0) + 0x1c8, 138067); //z
					writefloat(readValueL(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x4A0) + 0x3E8, 5763); //防拉
					writedword(UE4 + 0x949116C,-721215457); 
					}
					else{
					writedword(readValueL(readValueL(readValueL(UE4 + 0xDC10FF0) + 0x30) + 0x440) + 0x88, 167838216); 
}*/








                    if (忽略人坤) {
                        if (Player->bEnsure)
                            continue;
                    }
                    if (漏打) {
                        if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("Head", {0, 0, 0}), false))//头
                            if(!localController->LineOfSightTo(localController->/*落*/PlayerCameraManager,Player->GetBonePos("neck_01", {0, 0, 0}), false))//脖子
                                if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("upperarm_r", {0, 0, 0}), false))//上面的肩膀右
                                    if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("upperarm_l", {0, 0, 0}), false))//上面的肩膀左
                                        if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("lowerarm_r", {0, 0, 0}), false))//上面的手臂右
                                            if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("lowerarm_l", {0, 0, 0}), false))//上面的手臂左
                                                if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("spine_03", {0, 0, 0}), false))//脊柱3
                                                    if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("spine_02", {0, 0, 0}), false))//脊柱2
                                                        if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("spine_01", {0, 0, 0}), false))//脊柱2
                                                            if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("pelvis", {0, 0, 0}), false))//骨盆
                                                                if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("thigh_l", {0, 0, 0}), false))//大腿左
                                                                    if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("thigh_r", {0, 0, 0}), false))//大腿右
                                                                        if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("calf_l", {0, 0, 0}), false))//小腿左
                                                                            if(!localController->LineOfSightTo(localController->PlayerCameraManager,Player->GetBonePos("calf_r", {0, 0, 0}), false))//小腿右
                                                                                continue;

                        static bool 已选择 = false;
                        算法 = 0;
                        已选择 = false;
                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("Head", {0, 0, 0}),  false)) {//头
                            is头 = false;
                        } else {
                            is头 = true;
                        }
                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("pelvis", {0, 0, 0}),  false))
                        {   //骨盆
                            is盆骨 = false;
                        } else {
                            is盆骨 = true;
                        }


                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("neck_01", {0, 0, 0}),  false))
                        {   //脖子
                            is脖子 = false;
                        } else {
                            is脖子 = true;
                        }


                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("hand_l", {0, 0, 0}),  false))
                        {   //左手
                            is左手 = false;
                        } else {
                            is左手 = true;
                        }


                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("hand_r", {0, 0, 0}),  false))
                        {   //右手
                            is右手 = false;
                        } else {
                            is右手 = true;
                        }

                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("foot_l", {0, 0, 0}),  false))
                        {   //左脚
                            is左脚 = false;
                        } else {
                            is左脚 = true;
                        }

                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("foot_r", {0, 0, 0}),  false))
                        {   //右脚
                            is右脚 = false;
                        } else {
                            is右脚 = true;
                        }

                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("calf_l", {0, 0, 0}),  false))
                        {   //左小腿
                            is左小腿 = false;
                        } else {
                            is左小腿 = true;
                        }

                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("calf_r", {0, 0, 0}),  false))
                        {   //右小腿
                            is右小腿 = false;
                        } else {
                            is右小腿 = true;
                        }

                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("lowerarm_l", {0, 0, 0}),  false))
                        {   //左小臂
                            is左小臂 = false;
                        } else {
                            is左小臂 = true;
                        }
                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("lowerarm_r", {0, 0, 0}),  false))
                        {   //右小臂
                            is右小臂 = false;
                        } else {
                            is右小臂 = true;
                        }

                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("thigh_l", {0, 0, 0}),  false))
                        {   //左上臂
                            is左大腿 = false;
                        } else {
                            is左大腿 = true;
                        }
                        if(!localController->LineOfSightTo(localController->PlayerCameraManager, Player->GetBonePos("thigh_r", {0, 0, 0}),  false))
                        {   //左上臂
                            is右大腿 = false;
                        } else {
                            is右大腿 = true;
                        }




                        if (!已选择)
                            if(is头) {
                                算法 = 1;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is盆骨)
                            {
                                算法 = 2;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is左小腿)
                            {
                                算法 = 3;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is右小腿)
                            {
                                算法 = 4;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is左小臂)
                            {
                                算法 = 5;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is右小臂)
                            {
                                算法 = 6;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is左上臂)
                            {
                                算法 = 7;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is右上臂)
                            {
                                算法 = 8;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is左大腿)
                            {
                                算法 = 9;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is右大腿)
                            {
                                算法 = 10;
                                已选择 = true;
                            } else { //Config
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is左脚)
                            {
                                算法 = 11;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                        if (!已选择)
                            if(is右脚)
                            {
                                算法 = 12;
                                已选择 = true;
                            } else {
                                已选择 = false;
                            }
                    }
                    auto HeadPos = Player->GetBonePos("Head", {});
                    auto RootPos = Player->GetBonePos("Root", {});
                    FVector2D RootPosSC, HeadPosSC;
#define W2S(w, s) UGameplayStatics::ProjectWorldToScreen(localController, w, true, s)
                    if (W2S(HeadPos,&HeadPosSC)&&W2S(RootPos,&RootPosSC)) {
                        float height = abs(HeadPosSC.Y - RootPosSC.Y);
                        float width = height;
                        FVector middlePoint = {HeadPosSC.X + (width / 2), HeadPosSC.Y + (height / 2), 0};
                        if ((middlePoint.X >= 0 && middlePoint.X <= glWidth) &&
                                (middlePoint.Y >= 0 && middlePoint.Y <= glHeight)) {
                            FVector2D v2Middle = FVector2D((float) (glWidth / 2), (float) (glHeight / 2));
                            FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);
                            float dist = FVector2D::Distance(v2Middle, v2Loc);
                            if (dist < max) {
                                if (Fov((int) middlePoint.X, (int) middlePoint.Y)) {
                                    max = dist;
                                    result = Player;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}

auto GetTargetForBT() {
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();
    //float max2 = fov;
    auto GWorld = GetWorld();
    if (GWorld) {
        ULevel *PersistentLevel = GWorld->PersistentLevel;
        if (PersistentLevel) {
            TArray<AActor *> Actors = *(TArray<AActor *> *) ((uintptr_t) PersistentLevel +
                                      Actors_Offset);
            auto localPlayer = g_LocalPlayer;
            auto localController = g_LocalController;

            if (localPlayer) {
                for (int i = 0; i < Actors.Num(); i++) {
                    auto Actor = Actors[i];
                    if (isObjectInvalid(Actor))
                        continue;

                    if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                        auto Player = (ASTExtraPlayerCharacter *) Actor;


                        if (Player->PlayerKey == localPlayer->PlayerKey)
                            continue;

                        if (Player->TeamID == localPlayer->TeamID)
                            continue;

                        if (Player->bDead)
                            continue;


                        if (忽略倒地) {
                            if (Player->Health == 0.0f)
                                continue;
                        }

                        if (漏打) {
                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("Head", {0, 0, 0}), false))//头
                                if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("neck_01", {0, 0, 0}), false))//脖子
                                    if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("upperarm_r", {0, 0, 0}), false))//上面的肩膀右
                                        if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("upperarm_l", {0, 0, 0}), false))//上面的肩膀左
                                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("lowerarm_r", {0, 0, 0}), false))//上面的手臂右
                                                if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("lowerarm_l", {0, 0, 0}), false))//上面的手臂左
                                                    if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("spine_03", {0, 0, 0}), false))//脊柱3
                                                        if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("spine_02", {0, 0, 0}), false))//脊柱2
                                                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("spine_01", {0, 0, 0}), false))//脊柱2
                                                                if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("pelvis", {0, 0, 0}), false))//骨盆
                                                                    if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("thigh_l", {0, 0, 0}), false))//大腿左
                                                                        if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("thigh_r", {0, 0, 0}), false))//大腿右
                                                                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("calf_l", {0, 0, 0}), false))//小腿左
                                                                                if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager,Player->GetBonePos("calf_r", {0, 0, 0}), false))//小腿右
                                                                                    continue;



                            static bool 已选择 = false;
                            算法 = 0;
                            已选择 = false;
                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("Head", {0, 0, 0}),  false)) {//头
                                is头 = false;
                            } else {
                                is头 = true;
                            }
                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("pelvis", {0, 0, 0}),  false))
                            {   //骨盆
                                is盆骨 = false;
                            } else {
                                is盆骨 = true;
                            }


                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("neck_01", {0, 0, 0}),  false))
                            {   //脖子
                                is脖子 = false;
                            } else {
                                is脖子 = true;
                            }


                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("hand_l", {0, 0, 0}),  false))
                            {   //左手
                                is左手 = false;
                            } else {
                                is左手 = true;
                            }


                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("hand_r", {0, 0, 0}),  false))
                            {   //右手
                                is右手 = false;
                            } else {
                                is右手 = true;
                            }

                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("foot_l", {0, 0, 0}),  false))
                            {   //左脚
                                is左脚 = false;
                            } else {
                                is左脚 = true;
                            }

                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("foot_r", {0, 0, 0}),  false))
                            {   //右脚
                                is右脚 = false;
                            } else {
                                is右脚 = true;
                            }

                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("calf_l", {0, 0, 0}),  false))
                            {   //左小腿
                                is左小腿 = false;
                            } else {
                                is左小腿 = true;
                            }

                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("calf_r", {0, 0, 0}),  false))
                            {   //右小腿
                                is右小腿 = false;
                            } else {
                                is右小腿 = true;
                            }

                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("lowerarm_l", {0, 0, 0}),  false))
                            {   //左小臂
                                is左小臂 = false;
                            } else {
                                is左小臂 = true;
                            }
                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("lowerarm_r", {0, 0, 0}),  false))
                            {   //右小臂
                                is右小臂 = false;
                            } else {
                                is右小臂 = true;
                            }

                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("thigh_l", {0, 0, 0}),  false))
                            {   //左上臂
                                is左大腿 = false;
                            } else {
                                is左大腿 = true;
                            }
                            if(!g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, Player->GetBonePos("thigh_r", {0, 0, 0}),  false))
                            {   //左上臂
                                is右大腿 = false;
                            } else {
                                is右大腿 = true;
                            }




                            if (!已选择)
                                if(is头) {
                                    算法 = 1;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is盆骨)
                                {
                                    算法 = 2;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is左小腿)
                                {
                                    算法 = 3;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is右小腿)
                                {
                                    算法 = 4;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is左小臂)
                                {
                                    算法 = 5;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is右小臂)
                                {
                                    算法 = 6;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is左上臂)
                                {
                                    算法 = 7;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is右上臂)
                                {
                                    算法 = 8;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is左大腿)
                                {
                                    算法 = 9;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is右大腿)
                                {
                                    算法 = 10;
                                    已选择 = true;
                                } else { //Config
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is左脚)
                                {
                                    算法 = 11;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                            if (!已选择)
                                if(is右脚)
                                {
                                    算法 = 12;
                                    已选择 = true;
                                } else {
                                    已选择 = false;
                                }
                        }




                        if (忽略人坤) {
                            if (Player->bEnsure)
                                continue;
                        }

                        auto Root = Player->GetBonePos("Root", {});
                        auto Head = Player->GetBonePos("Head", {});

                        FVector2D RootSc, HeadSc;
                        if (W2S(Root, &RootSc) && W2S(Head, &HeadSc)) {
                            float height = abs(HeadSc.Y - RootSc.Y);
                            float width = height * 0.65f;

                            FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2),
                                                   0
                                                  };
                            if ((middlePoint.X >= 0 && middlePoint.X <= glWidth) &&
                                    (middlePoint.Y >= 0 && middlePoint.Y <= glHeight)) {
                                FVector2D v2Middle = FVector2D((float) (glWidth / 2),
                                                               (float) (glHeight / 2));
                                FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);

                                // float dist = FVector2D::Distance(v2Middle, v2Loc);
                                if(isInsideFov((int)middlePoint.X, (int)middlePoint.Y)) {

                                    float dist = FVector2D::Distance(v2Middle, v2Loc);
                                    // if(max2 > dist){
                                    if (dist < max) {
                                        max = dist;
                                        result = Player;

                                    }

                                }
                            }

                        }
                    }
                }
            }
        }
        return result;
    }
}

auto GetTargetForBT2() {
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();

    auto Actors = getActors();
    auto localPlayer = g_LocalPlayer;
    auto localController = g_LocalController;

    if (localPlayer) {
        for (int i = 0; i < Actors.Num(); i++)
        {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                auto Player = (ASTExtraPlayerCharacter *) Actor;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;

                if (Player->TeamID == localPlayer->TeamID)
                    continue;

                if (Player->bDead)
                    continue;

                if (忽略倒地) {
                    if (Player->Health == 0.0f)
                        continue;
                }

                if (漏打) {
                    if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }

                if (忽略人坤) {
                    if (Player->bEnsure)
                        continue;
                }


                float dist = localPlayer->GetDistanceTo(Player);
                if (dist < max) {
                    max = dist;
                    result = Player;
                }
            }
        }
    }


    return result;
}


bool 头部1;
bool 头部2;


void (*orig_shoot_event)(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot, void *unk1, int unk2) = 0;

bool qwcifqvs86y8fify = false;

void shoot_event(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot, ASTExtraShootWeapon *weapon, int unk1) {




    if (qwcifqvs86y8fify) {
        qwcifqvs86y8fify = false;
        g_LocalController->bIsPressingFireBtn = false;
        thiz->OwnerShootWeapon->StopFire(EFreshWeaponStateType::FreshWeaponStateType_Idle);
    }
    if (追踪&&追踪状态) {
        if (配置2) {
            ASTExtraPlayerCharacter *Target = GetTargetForBT2();
            if (Target) {
                bool triggerOk = false;
                triggerOk = g_LocalPlayer->bIsWeaponFiring || g_LocalPlayer->bIsGunADS;
                if (triggerOk) {
                    if (头部) {
                        targetAimPos = Target->GetBonePos("Head", {});
                        targetAimPos.Z -= -1.0f;
                    } else if (身体) {
                        targetAimPos = Target->GetBonePos("Head", {});//锁骨
                        targetAimPos.Z -= 5.0f;
                    }
//NIKE&&神乐&&静默子追打鸟预判&仿Ts
                    FRotator sex = ToRotator(start, targetAimPos);
                    targetAimPos.Z -= g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, targetAimPos, true);
                    return orig_shoot_event(thiz, start, rot, weapon, unk1);
                }
            }
        }
        if (配置1) {
            ASTExtraPlayerCharacter *Target = GetTargetForBT();
            if (Target) {
                bool triggerOk = false;
                triggerOk = g_LocalPlayer->bIsWeaponFiring || g_LocalPlayer->bIsGunADS;
                if (triggerOk) {
                    FVector targetAimPos;
                    if (漏打) {
                        if (头部) {
                            if (安全) {
                                if (头部1) {
                                    if(算法 == 0) {
                                        targetAimPos = Target->GetBonePos("Head", {});
                                        targetAimPos.Z -= -8.0f;
                                    } else if(算法 == 1) {
                                        targetAimPos = Target->GetBonePos("Head", {});
                                        targetAimPos.Z -= -8.0f;
                                    } else if(算法 == 2) {
                                        targetAimPos = Target->GetBonePos("pelvis", {});//锁骨
                                    } else if(算法 == 3) {
                                        targetAimPos = Target->GetBonePos("calf_l", {});//左小腿
                                    } else if(算法 == 4) {
                                        targetAimPos = Target->GetBonePos("calf_r", {});//右小腿
                                    } else if(算法 == 5) {
                                        targetAimPos = Target->GetBonePos("lowerarm_l", {});//左小臂
                                    } else if(算法 == 6) {
                                        targetAimPos = Target->GetBonePos("lowerarm_r", {});//右小臂
                                    } else if(算法 == 7) {
                                        targetAimPos = Target->GetBonePos("upperarm_l", {});//左上臂
                                    } else if(算法 == 8) {
                                        targetAimPos = Target->GetBonePos("upperarm_r", {});//右上臂
                                    } else if(算法 == 9) {
                                        targetAimPos = Target->GetBonePos("thigh_l", {});//左大腿
                                    } else if(算法 == 10) {
                                        targetAimPos = Target->GetBonePos("thigh_r", {});//右大腿
                                    } else if(算法 == 11) {
                                        targetAimPos = Target->GetBonePos("foot_l", {});//左脚
                                    } else if(算法 == 12) {
                                        targetAimPos = Target->GetBonePos("foot_r", {});//右脚
                                    }
                                } else if (头部2) {
                                    if(算法 == 0) {
                                        targetAimPos = Target->GetBonePos("Head", {});
                                        targetAimPos.Z -= 6.5f;
                                    } else if(算法 == 1) {
                                        targetAimPos = Target->GetBonePos("Head", {});//锁骨
                                        targetAimPos.Z -= 6.5f;
                                    } else if(算法 == 2) {
                                        targetAimPos = Target->GetBonePos("pelvis", {});//锁骨
                                    } else if(算法 == 3) {
                                        targetAimPos = Target->GetBonePos("calf_l", {});//左小腿
                                    } else if(算法 == 4) {
                                        targetAimPos = Target->GetBonePos("calf_r", {});//右小腿
                                    } else if(算法 == 5) {
                                        targetAimPos = Target->GetBonePos("lowerarm_l", {});//左小臂
                                    } else if(算法 == 6) {
                                        targetAimPos = Target->GetBonePos("lowerarm_r", {});//右小臂
                                    } else if(算法 == 7) {
                                        targetAimPos = Target->GetBonePos("upperarm_l", {});//左上臂
                                    } else if(算法 == 8) {
                                        targetAimPos = Target->GetBonePos("upperarm_r", {});//右上臂
                                    } else if(算法 == 9) {
                                        targetAimPos = Target->GetBonePos("thigh_l", {});//左大腿
                                    } else if(算法 == 10) {
                                        targetAimPos = Target->GetBonePos("thigh_r", {});//右大腿
                                    } else if(算法 == 11) {
                                        targetAimPos = Target->GetBonePos("foot_l", {});//左脚
                                    } else if(算法 == 12) {
                                        targetAimPos = Target->GetBonePos("foot_r", {});//右脚
                                    }
                                }
                            } else if (残酷) {
                                if(算法 == 0) {
                                    targetAimPos = Target->GetBonePos("Head", {});
                                    targetAimPos.Z -= -8.0f;
                                } else if(算法 == 1) {
                                    targetAimPos = Target->GetBonePos("Head", {});
                                    targetAimPos.Z -= -8.0f;
                                } else if(算法 == 2) {
                                    targetAimPos = Target->GetBonePos("pelvis", {});//锁骨
                                } else if(算法 == 3) {
                                    targetAimPos = Target->GetBonePos("calf_l", {});//左小腿
                                } else if(算法 == 4) {
                                    targetAimPos = Target->GetBonePos("calf_r", {});//右小腿
                                } else if(算法 == 5) {
                                    targetAimPos = Target->GetBonePos("lowerarm_l", {});//左小臂
                                } else if(算法 == 6) {
                                    targetAimPos = Target->GetBonePos("lowerarm_r", {});//右小臂
                                } else if(算法 == 7) {
                                    targetAimPos = Target->GetBonePos("upperarm_l", {});//左上臂
                                } else if(算法 == 8) {
                                    targetAimPos = Target->GetBonePos("upperarm_r", {});//右上臂
                                } else if(算法 == 9) {
                                    targetAimPos = Target->GetBonePos("thigh_l", {});//左大腿
                                } else if(算法 == 10) {
                                    targetAimPos = Target->GetBonePos("thigh_r", {});//右大腿
                                } else if(算法 == 11) {
                                    targetAimPos = Target->GetBonePos("foot_l", {});//左脚
                                } else if(算法 == 12) {
                                    targetAimPos = Target->GetBonePos("foot_r", {});//右脚
                                }
                            }
                        }  else if (身体) {
                            if(算法 == 0) {
                                targetAimPos = Target->GetBonePos("Head", {});
                                targetAimPos.Z -= 6.5f;
                            } else if(算法 == 1) {
                                targetAimPos = Target->GetBonePos("Head", {});//锁骨
                                targetAimPos.Z -= 6.5f;
                            } else if(算法 == 2) {
                                targetAimPos = Target->GetBonePos("pelvis", {});//锁骨
                            } else if(算法 == 3) {
                                targetAimPos = Target->GetBonePos("calf_l", {});//左小腿
                            } else if(算法 == 4) {
                                targetAimPos = Target->GetBonePos("calf_r", {});//右小腿
                            } else if(算法 == 5) {
                                targetAimPos = Target->GetBonePos("lowerarm_l", {});//左小臂
                            } else if(算法 == 6) {
                                targetAimPos = Target->GetBonePos("lowerarm_r", {});//右小臂
                            } else if(算法 == 7) {
                                targetAimPos = Target->GetBonePos("upperarm_l", {});//左上臂
                            } else if(算法 == 8) {
                                targetAimPos = Target->GetBonePos("upperarm_r", {});//右上臂
                            } else if(算法 == 9) {
                                targetAimPos = Target->GetBonePos("thigh_l", {});//左大腿
                            } else if(算法 == 10) {
                                targetAimPos = Target->GetBonePos("thigh_r", {});//右大腿
                            } else if(算法 == 11) {
                                targetAimPos = Target->GetBonePos("foot_l", {});//左脚
                            } else if(算法 == 12) {
                                targetAimPos = Target->GetBonePos("foot_r", {});//右脚
                            }
                        }

                    } else {
                        if (头部) {
                            if (安全) {
                                if (头部1) {
                                    targetAimPos = Target->GetBonePos("Head", {});
                                    targetAimPos.Z -= -8.0f;
                                } else if (头部2) {

                                }
                            } else if (残酷) {
                                targetAimPos = Target->GetBonePos("Head", {});
                                targetAimPos.Z -= -8.0f;
                            }
                        } else if (身体) {
                            targetAimPos = Target->GetBonePos("Head", {});//锁骨
                            targetAimPos.Z -= 6.5f;
                        }
                    }
//NIKE&&神乐&&静默子追打鸟预判&仿Ts
                    FRotator sex = ToRotator(start, targetAimPos);
                    targetAimPos.Z -= g_LocalController->LineOfSightTo(g_LocalController->PlayerCameraManager, targetAimPos, true);
                    return orig_shoot_event(thiz, targetAimPos, sex, weapon, unk1);
                }
            }

        }
    }

    return orig_shoot_event(thiz, start, rot, weapon, unk1);
}


// ================================================================================================================================ //

class FPSCounter {
protected:
    unsigned int m_fps;
    unsigned int m_fpscount;
    long m_fpsinterval;

public:
    FPSCounter() : m_fps(0), m_fpscount(0), m_fpsinterval(0) {
    }

    void update() {
        m_fpscount++;

        if (m_fpsinterval < time(0)) {
            m_fps = m_fpscount;

            m_fpscount = 0;
            m_fpsinterval = time(0) + 1;
        }
    }

    unsigned int get() const {
        return m_fps;
    }
};

FPSCounter fps;


void DrawBoxEnemy(ImDrawList *draw, ImVec2 X, ImVec2 Y, float thicc, float rounding, int color) {
    draw->AddLine({X.x, X.y}, {Y.x, Y.y}, color, thicc);
}

void VectorAnglesRadar(Vector3 & forward, FVector & angles) {
    if (forward.X == 0.f && forward.Y == 0.f) {
        angles.X = forward.Z > 0.f ? -90.f : 90.f;
        angles.Y = 0.f;
    } else {
        angles.X = RAD2DEG(atan2(-forward.Z, forward.Magnitude(forward)));
        angles.Y = RAD2DEG(atan2(forward.Y, forward.X));
    }
    angles.Z = 0.f;
}

void RotateTriangle(std::array<Vector3, 3> & points, float rotation) {
    const auto points_center = (points.at(0) + points.at(1) + points.at(2)) / 3;
    for (auto & point : points) {
        point = point - points_center;
        const auto temp_x = point.X;
        const auto temp_y = point.Y;
        const auto theta = DEG2RAD(rotation);
        const auto c = cosf(theta);
        const auto s = sinf(theta);
        point.X = temp_x * c - temp_y * s;
        point.Y = temp_x * s + temp_y * c;
        point = point + points_center;
    }
}

FVector2D pushToScreenBorder(FVector2D Pos, FVector2D screen, int borders, int offset) {
    int x = (int)Pos.X;
    int y = (int)Pos.Y;
    if ((borders & 1) == 1) {
        y = 0 - offset;
    }
    if ((borders & 2) == 2) {
        x = (int)screen.X + offset;
    }
    if ((borders & 4) == 4) {
        y = (int)screen.Y + offset;
    }
    if ((borders & 8) == 8) {
        x = 0 - offset;
    }
    return FVector2D(x, y);
}

int isOutsideSafezone(FVector2D pos, FVector2D screen) {
    FVector2D mSafezoneTopLeft(screen.X * 0.04f, screen.Y * 0.04f);
    FVector2D mSafezoneBottomRight(screen.X * 0.96f, screen.Y * 0.96f);
    int result = 0;
    if (pos.Y < mSafezoneTopLeft.Y) {
        result |= 1;
    }
    if (pos.X > mSafezoneBottomRight.X) {
        result |= 2;
    }
    if (pos.Y > mSafezoneBottomRight.Y) {
        result |= 4;
    }
    if (pos.X < mSafezoneTopLeft.X) {
        result |= 8;
    }
    return result;
}

void Box4Line(ImDrawList *draw, float thicc, int x, int y, int w, int h, int color) {
    int iw = w / 4;
    int ih = h / 4;
    // top
    draw->AddRect(ImVec2(x, y),ImVec2(x + iw, y), color, thicc);
    draw->AddRect(ImVec2(x + w - iw, y),ImVec2(x + w, y), color, thicc);
    draw->AddRect(ImVec2(x, y),ImVec2(x, y + ih), color, thicc);
    draw->AddRect(ImVec2(x + w - 1, y),ImVec2(x + w - 1, y + ih), color, thicc);;
    // bottom
    draw->AddRect(ImVec2(x, y + h),ImVec2(x + iw, y + h), color, thicc);
    draw->AddRect(ImVec2(x + w - iw, y + h),ImVec2(x + w, y + h), color, thicc);
    draw->AddRect(ImVec2(x, y + h - ih), ImVec2(x, y + h), color, thicc);
    draw->AddRect(ImVec2(x + w - 1, y + h - ih), ImVec2(x + w - 1, y + h), color, thicc);
}

void DrawBoxEnemy(ImDrawList *draw, ImVec2 X, ImVec2 Y, float thicc, int color) {
    draw->AddLine({X.x, X.y}, {Y.x, Y.y}, color, thicc);
}

void DrawFilledRectangle(int x, int y, int w, int h, ImU32 col, float rounding) {
    ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + h), col, rounding);
}

void DrawRectangle(int x, int y, int w, int h, ImU32 col, float rounding) {
    ImGui::GetBackgroundDrawList()->AddRect(ImVec2(x, y), ImVec2(x + w, y + h), col, rounding);
}
void Line(ImDrawList *draw,FVector2D origin, FVector2D dest, ImColor color)
{
    draw->AddLine({origin.X, origin.Y}, {dest.X, dest.Y},color, 1.0f);
}
bool W2S2(FVector worldPos, FVector2D *screenPos) {
    return g_LocalController->ProjectWorldLocationToScreen(worldPos, true, screenPos);
}
FVector WorldToRadar(float Yaw, FVector Origin, FVector LocalOrigin, float PosX, float PosY, Vector3 Size, bool &outbuff) {
    bool flag = false;
    double num = (double)Yaw;
    double num2 = num * 0.017453292519943295;
    float num3 = (float)std::cos(num2);
    float num4 = (float)std::sin(num2);
    float num5 = Origin.X - LocalOrigin.X;
    float num6 = Origin.Y - LocalOrigin.Y;
    struct FVector Xector;
    Xector.X = (num6 * num3 - num5 * num4) / 150.f;
    Xector.Y = (num5 * num3 + num6 * num4) / 150.f;
    struct FVector Xector2;
    Xector2.X = Xector.X + PosX + Size.X / 2.f;
    Xector2.Y = -Xector.Y + PosY + Size.Y / 2.f;
    bool flag2 = Xector2.X > PosX + Size.X;
    if (flag2) {
        Xector2.X = PosX + Size.X;
    } else {
        bool flag3 = Xector2.X < PosX;
        if (flag3) {
            Xector2.X = PosX;
        }
    }
    bool flag4 = Xector2.Y > PosY + Size.Y;
    if (flag4) {
        Xector2.Y = PosY + Size.Y;
    } else {
        bool flag5 = Xector2.Y < PosY;
        if (flag5) {
            Xector2.Y = PosY;
        }
    }
    bool flag6 = Xector2.Y == PosY || Xector2.X == PosX;
    if (flag6) {
        flag = true;
    }
    outbuff = flag;
    return Xector2;
}




int 跳转浏览器(const char* url)
{
    JavaVM* java_vm = g_App->activity->vm;
    JNIEnv* java_env = NULL;
    jint jni_return = java_vm->GetEnv((void**)&java_env, JNI_VERSION_1_6);
    if (jni_return == JNI_ERR)
        return -1;
    jni_return = java_vm->AttachCurrentThread(&java_env, NULL);
    if (jni_return != JNI_OK)
        return -2;
    jclass native_activity_clazz = java_env->GetObjectClass(g_App->activity->clazz);
    if (native_activity_clazz == NULL)
        return -3;
    jmethodID method_id = java_env->GetMethodID(native_activity_clazz, "AndroidThunkJava_LaunchURL", "(Ljava/lang/String;)V");
    if (method_id == NULL)
        return -4;
    jstring retStr = java_env->NewStringUTF(url);
    java_env->CallVoidMethod(g_App->activity->clazz, method_id, retStr);
    jni_return = java_vm->DetachCurrentThread();
    if (jni_return != JNI_OK)
        return -5;
    return 0;
}



void 加载瞄准() {
    int fd = open("/data/data/com.tencent.ig/files/liangmo", O_RDONLY);
    read(fd, &追踪, sizeof(追踪));
    read(fd, &忽略人坤, sizeof(忽略人坤));
    read(fd, &忽略倒地, sizeof(忽略倒地));
    read(fd, &自动开火, sizeof(自动开火));
    read(fd, &漏打, sizeof(漏打));
    read(fd, &范围, sizeof(范围));
    read(fd, &线条, sizeof(线条));
    read(fd, &骨骼, sizeof(骨骼));
    read(fd, &血量1, sizeof(血量1));
    read(fd, &血量2, sizeof(血量2));
    read(fd, &名字, sizeof(名字));
    read(fd, &距离, sizeof(距离));
    read(fd, &绘制狗子, sizeof(车辆));
    read(fd, &盒子, sizeof(盒子));
    read(fd, &忽略人机, sizeof(忽略人机));
    close(fd);
}

void 保存瞄准() {
    int fd = open("/data/data/com.tencent.ig/files/liangmo", O_WRONLY | O_CREAT);
    system("chmod 777 /data/data/com.tencent.ig/files/liangmo");
    write(fd, &追踪, sizeof(追踪));
    write(fd, &忽略人坤, sizeof(忽略人坤));
    write(fd, &忽略倒地, sizeof(忽略倒地));
    write(fd, &自动开火, sizeof(自动开火));
    write(fd, &漏打, sizeof(漏打));
    write(fd, &范围, sizeof(范围));
    write(fd, &线条, sizeof(线条));
    write(fd, &骨骼, sizeof(骨骼));
    write(fd, &血量1, sizeof(血量1));
    write(fd, &血量2, sizeof(血量2));
    write(fd, &名字, sizeof(名字));
    write(fd, &距离, sizeof(距离));
    write(fd, &绘制狗子, sizeof(车辆));
    write(fd, &盒子, sizeof(盒子));
    write(fd, &忽略人机, sizeof(忽略人机));
    close(fd);
}



/*void 加载配置()
{
int fd = open("/sdcard/Android/liangmo", O_RDONLY);
read(fd, &射线, sizeof(射线));
read(fd, &方框, sizeof(方框)); 
read(fd, &骨骼, sizeof(骨骼));  
read(fd, &星星, sizeof(星星));  
read(fd, &名称, sizeof(名字1));     
read(fd, &距离, sizeof(距离1));   
read(fd, &预警, sizeof(敌背));   
read(fd, &血量, sizeof(血量2));   
read(fd, &人数, sizeof(剩余人数));   
read(fd, &忽机, sizeof(隐藏人机));   
read(fd, &漏打开关, sizeof(漏打));   
read(fd, &自动开火, sizeof(自动开火));   
read(fd, &忽略倒地, sizeof(忽略倒地));   
read(fd, &子弹追踪, sizeof(子弹追踪));   
close(fd);
}

*/

void 保存配置()
{   
int fd = open("/sdcard/Android/liangmo", O_WRONLY | O_CREAT);
system("chmod 777 /sdcard/Android/liangmo");
write(fd, &线条, sizeof(线条));
//]write(fd, &方框, sizeof(方框)); 
write(fd, &骨骼, sizeof(骨骼));  
//write(fd, &星星, sizeof(星星));  
write(fd, &名字, sizeof(名字));     
write(fd, &距离, sizeof(距离));   
//write(fd, &预警, sizeof(预警));   
write(fd, &血量1, sizeof(血量1));   
//write(fd, &人数, sizeof(剩余人数));   
write(fd, &忽略人机, sizeof(忽略人机));   
write(fd, &漏打, sizeof(漏打));   
write(fd, &自动开火, sizeof(自动开火));   
write(fd, &忽略倒地, sizeof(忽略倒地));   
write(fd, &追踪, sizeof(追踪));   
close(fd);
}


float 测试 = 2;
void drawHexagonStar(float x, float y, float size, float rotation, ImDrawList* draw, ImU32 color) {
    const int numPoints = 6; // 六角星有6个顶点
    ImVec2 center(x, y);
    ImVec2 points[numPoints];
    for (int i = 0; i < numPoints; i++)
    {
        float angle = rotation + 测试 * IM_PI * i / numPoints;
        points[i] = ImVec2(center.x + size * cos(angle), center.y + size * sin(angle));
    }
    // 绘制两个大三角形
    ImGui::GetForegroundDrawList()->AddLine(points[0], points[2], color, 1.0f);
    ImGui::GetForegroundDrawList()->AddLine(points[2], points[4], color, 1.0f);
    ImGui::GetForegroundDrawList()->AddLine(points[4], points[0], color, 1.0f);
    ImGui::GetForegroundDrawList()->AddLine(points[1], points[3], color, 1.0f);
    ImGui::GetForegroundDrawList()->AddLine(points[3], points[5], color, 1.0f);
    ImGui::GetForegroundDrawList()->AddLine(points[5], points[1], color, 1.0f);
}
void DrawLogo(float x, float y, float size, float size2) {
    // 添加绘制六角星并旋转的代码
    static float rotation = 0.0f; // 初始旋转角度
    rotation += 0.05f; // 调整旋转速度
    // 获取绘图列表
    ImDrawList* draw = ImGui::GetForegroundDrawList();
    // 在指定位置绘制一个黄色六角星，大小为size，旋转角度为rotation
    drawHexagonStar(x, y, size, rotation, draw, 白色);
    // 绘制包裹六角星的圆形
    // 设置文字缩放比例
}
bool 电梯;
bool 定飞;
bool 实体;
bool 加速;
bool 飞天;
bool 过检验;
bool 开关;
bool 循环;
bool 锁地形;
bool 校验开关;
bool 传送开关;
bool 加速开关;
bool is定飞;
bool 传送;
bool 淫叫;
bool 僵尸来了;

int 校验1,校验2,校验3,校验4;
int 加速自改=11;
int 定飞自改=14;
void MThread()
{
	while(true)
	{
		long int 自身 = RUI(RUI(RUI(RUI(UE4Bss + 0x640858 ) + 0x8 ) + 0x48 ) + 0x20 );
		long int 矩阵 = RUI(RUI(UE4Bss + 0x59F1C0 )+ 0x20 )+ 0x27C;
		long int 坐标 = RUI(自身 + 0x1B0) + 0x1C0;
        long int 灵魂 = RUI(自身 + 0x4A0) + 0xC8;
		
		if(过检验)
		{
            
			long int 检验地址 = RUI ( 自身 +  0x4A0)+ 0x3BC;
			if(!校验开关)
			{
				校验1 = getdword(检验地址);
                校验2 = getdword(检验地址 + 0x4);
                校验3 = getdword(检验地址 + 0x8);
                校验4 = getdword(检验地址 + 0xC);
				
				校验开关 = true;
			}
			
			写入D类(检验地址,校验1);
            写入D类(检验地址 + 0x4,校验2);
            写入D类(检验地址 + 0x8,校验3);
            写入D类(检验地址 + 0xC,校验4);
			
		}
		else
		{
			校验开关 = false;
		}
		
		//if(开关)
				if(传送)
		{
			if(!传送开关)
            {
                写入D类(灵魂,0);
                int i = 0;
                while(i <= 2000)
                {
                    自身 = RUI(RUI(RUI(RUI(UE4Bss + 0x640858 ) + 0x8 ) + 0x48 ) + 0x20 );//自身
                    坐标 = RUI(自身 + 0x1B0) + 0x1C0;
                    写入F类<float>(坐标, 76754.8671875);
                    写入F类<float>(坐标 + 0x4,131487.703125);
                    写入F类<float>(坐标 + 0x8,119.93465423584);
                    i++;
                }

                sleep(2);
                锁地形 = true;
				过检验 = true;
                写入D类(RUI(自身 + 0x4A0)+0x3E8,54148);
                写入F类<float>(RUI(UE4Bss + 0x1FC8)+0x34,144);
                写入F类<float>(RUI(UE4Bss + 0x1FC8)+0x38,144);
                写入D类(UE4+0x949116C,-721215457);
                锁地形 = true;
                传送开关 = true;
                                写入D类(灵魂,1847296);
            }
            
		
	//	if(循环)
         // if(实体)
        //  {
            long int Uworld = 自身;
            long int Uleve = RUI(Uworld + 0x20);
            long int arrayaddr = RUI(Uleve + 0xA0);	// 世界偏移
            long int count = getdword(Uleve + 0xA8);//数组数量
            long int team = getdword(Uworld + 0x938);//自身队伍

            for (int i = 0; i < count; i++)
            {
                long int objaddrzz = RUI(arrayaddr + 8 * i);
                int 探头 = getdword(Uworld + 0x2838);
                int 挥拳 = getdword(RUI(Uworld + 0xF00)+ 0x800);

                if(挥拳 == 1)
                {
                    if(getfloat(矩阵 + 0x20) > 0.85)
                    {
                        写入F类<float>(坐标 + 0x8,0.15 + getfloat(坐标 + 0x8));
                    }
                    else
                    {
                        写入F类<float>(坐标,getfloat(矩阵)*0.25 + getfloat(坐标));
                        写入F类<float>(坐标+0x4,getfloat(矩阵 + 0x10 )*0.25 + getfloat(坐标+0x4));
                    }
                }

                if(getdword(Uworld + 0xF80) == 16)
                {
                    写入F类<float>(坐标 + 0x8,0.1 + getfloat(坐标 + 0x8));
                }

                if(getdword(Uworld + 0x2838) == 16842752)
                {
                    if(getfloat(objaddrzz + 0x2860) == 479.5 && getdword(objaddrzz + 0x938) != team && getfloat(objaddrzz + 0xDC0) > 1 )
                    {
                        while(getfloat(objaddrzz + 0xDC0) > 1)
                        {
                            if(!实体 || getdword(Uworld + 0x2838) != 16842752)
                            {
                                break;
                            }

                            long int 坐标 = RUI(Uworld + 0x1b0)+0x1c0;
                            long int 敌人坐标 = RUI(objaddrzz + 0x1b0)+0x1c0;

                            写入F类<float>(坐标,getfloat(敌人坐标) + 100);
                            写入F类<float>(坐标 + 0x4,getfloat(敌人坐标 + 0x4) );
                            写入F类<float>(坐标 + 0x8,getfloat(敌人坐标 + 0x8) + 150);

                        }
                    }
                }
            }
		}
		
		else
		{
			if(传送开关)
            {
                传送开关 = false;
                锁地形 = false;
				过检验 = false;
            }
		}
		
		if(定飞){
            if(!is定飞)
            {
                写入D类(灵魂,0);
                int i = 0;
                while(i <= 2000)
                {
					自身 = RUI(RUI(RUI(RUI(UE4Bss + 0x640858 ) + 0x8 ) + 0x48 ) + 0x20 );//自身
        		    坐标 = RUI(自身 + 0x1B0) + 0x1C0;
                    写入F类<float>(坐标, 118745.9921875);
                    写入F类<float>(坐标 + 0x4,109173.9453125);
                    写入F类<float>(坐标 + 0x8,236.55001831055);
                    i++;
                }
                sleep(2);
                写入D类(UE4+0x949116C,-721215457);
                锁地形 = true;
				过检验 = true;
                写入D类(RUI(自身 + 0x4A0)+0x3E8,54148);
                写入F类<float>(RUI(UE4Bss + 0x1FC8)+0x34,144);
                写入F类<float>(RUI(UE4Bss + 0x1FC8)+0x38,144);
                写入D类(灵魂,1847296);
              
             //   if(飞天){
				 写入F类<float>(RUI(自身 + 0x4A0)+ 0x208,9999999);
				 写入F类<float>(RUI(自身 + 0x4A0)+ 0x1BC,0);
				 写入F类<float>(RUI(自身 + 0x4A0)+ 0x1B4,0);
				 写入F类<float>(RUI(RUI(自身 + 0x398)+0x8)+0x360,0);
				 写入F类<float>(RUI(自身 + 0x4A0)+ 0x220,6000000);
				 写入F类<float>(RUI(自身 + 0x4A0)+0x550,0.01);
                long int 变速 =RUI(RUI(RUI(RUI(RUI( UE4Bss + 0x5A5FF0)+0x30)+0x458)+0x20)+0x400)+0x6F0;

                写入F类<float>(变速,0.0001);
                写入F类<float>(变速 - 0x14,1.6);
                写入F类<float>(变速 - 0x18,90);
                写入F类<float>(自身 + 0x1080,定飞自改);
                is定飞 = true;
            }
        }
        
        else
        {
            if(is定飞)
            {
                写入D类(UE4 + 0x949116C,-117286283);
                写入F类<float>(UE4 + 0x52AEAEC,8.61612006e-21);
                写入F类<float>(UE4 + 0xBD75148,8.52492339e-21);

                写入F类<float>(RUI(自身 + 0x498)+ 0xB50,1);
                写入F类<float>(自身 + 0x1080,1);

                long int 变速 =RUI(RUI(RUI(RUI(RUI( UE4Bss + 0x5A5FF0)+0x30)+0x458)+0x20)+0x400)+0x6F0;

                写入F类<float>(变速,0.4);
                写入F类<float>(变速 - 0x14,1);
                写入F类<float>(变速 - 0x18,1);

                写入F类<float>(RUI(自身 + 0x4A0)+0x208,8192);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208 - 0x54,1);
                写入F类<float>(RUI(自身 + 0x4A0)+0x1BC,443);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208 - 0x50,45);
                写入F类<float>(RUI(自身 + 0x4A0)+0x550,240);
                写入F类<float>(自身 + 0x1080-0xFFC,1);
                写入F类<float>(RUI(自身 + 0x4A0)+0xB58,670);
                写入F类<float>(自身 + 0x1080,1);
                写入F类<float>(RUI(自身 + 0x4A0)+ 0x220,0);
                
                锁地形 = false;
                过检验 = false;
                is定飞 = false;
            }
        }
		
		if(电梯)
		{
			if(!加速开关)
			{
				写入D类(灵魂,0);
                int i = 0;
                while(i <= 2000)
                {
                    自身 = RUI(RUI(RUI(RUI(UE4Bss + 0x640858 ) + 0x8 ) + 0x48 ) + 0x20 );//自身
                    坐标 = RUI(自身 + 0x1B0) + 0x1C0;
                    写入F类<float>(坐标, 118745.9921875);
                    写入F类<float>(坐标 + 0x4,109173.9453125);
                    写入F类<float>(坐标 + 0x8,236.55001831055);
                    i++;
                }

                sleep(2);
                锁地形 = true;
				过检验 = true;
                写入D类(RUI(自身 + 0x4A0)+0x3E8,54148);
                写入F类<float>(RUI(UE4Bss + 0x1FC8)+0x34,144);
                写入F类<float>(RUI(UE4Bss + 0x1FC8)+0x38,144);
                写入D类(UE4+0x949116C,-721215457);
                写入D类(灵魂,1847296);
                
               // if(加速){
                写入F类<float>(RUI(自身 + 0x4A0)+0x22C,9999999);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208-0x50,85);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208+0x7c,0);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208+0x348,0);

                写入F类<float>(RUI(自身 + 0x4A0)+0x208,1.0e10);
                写入F类<float>(自身 + 0x1080-0xFFC,0.6);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208-0x54,9.6);
                写入F类<float>(RUI(自身 + 0x4A0)+0x1BC,7500);
                写入F类<float>(自身 + 0x1080+0x18a8,加速自改);


                long int 变速 =RUI(RUI(RUI(RUI(RUI( UE4Bss + 0x5A5FF0)+0x30)+0x458)+0x20)+0x400)+0x6F0;

                写入F类<float>(变速,0.0001);
                写入F类<float>(变速 - 0x14,1.7);
                写入F类<float>(变速 - 0x18,90);

                写入F类<float>(RUI(RUI(UE4Bss + 0x5A5FF0)+0x30)+0x84,999999);

                写入F类<float>(UE4 + 0x52AEAEC,8.95671814e-21);
                写入F类<float>(UE4 + 0xBD75148,8.95671814e-21);
				
				加速开关 = true;
			}
			写入F类<float>(RUI(自身 + 0x4A0)+0xb58,500);
		}
		
		else
		{
			if(加速开关)
			{
				写入D类(UE4 + 0x949116C,-117286283);
                写入F类<float>(UE4 + 0x52AEAEC,8.61612006e-21);
                写入F类<float>(UE4 + 0xBD75148,8.52492339e-21);

                写入F类<float>(RUI(自身 + 0x498)+ 0xB50,1);
                写入F类<float>(自身 + 0x1080+0x18a8,1);

                long int 变速 =RUI(RUI(RUI(RUI(RUI( UE4Bss + 0x5A5FF0)+0x30)+0x458)+0x20)+0x400)+0x6F0;

                写入F类<float>(变速,0.4);
                写入F类<float>(变速 - 0x14,1);
                写入F类<float>(变速 - 0x18,1);

                写入F类<float>(RUI(自身 + 0x4A0)+0x208,8192);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208 - 0x54,1);
                写入F类<float>(RUI(自身 + 0x4A0)+0x1BC,443);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208 - 0x50,45);
                写入F类<float>(RUI(自身 + 0x4A0)+0x208 + 0x348,240);
                写入F类<float>(自身 + 0x1080-0xFFC,1);
                写入F类<float>(RUI(自身 + 0x4A0)+0xB58,670);
                写入F类<float>(自身 + 0x1080,1);
				
				加速开关 = false;
				过检验 = false;
			}
		}
		
		if(!传送 && !加速 && !飞天)
		{
			if(锁地形)
			{
				写入D类(UE4+0x949116C,-117286283);
				锁地形 = false;
			}
		}
	}
}

void DrawESP(ImDrawList*draw,int screenWidth, int screenHeight) {
    float starX = glWidth / 4;
    float starY = glHeight / 10;
    float starSize = 40.0f; // 设置六角星的大小
    float starSize2 = 24.0f;
    DrawLogo(starX, starY, starSize, starSize2);
    auto Actors = getActors();

    for (int i = 0; i < Actors.Num(); i++) {
        auto Actor = Actors[i];
        if (isObjectInvalid(Actor))
            continue;

        if (Actor->IsA(ASTExtraPlayerController::StaticClass())) {
            g_LocalController = (ASTExtraPlayerController *) Actor;
            break;
        }
    }

if(准心rgb)
        {
            rgb=rgb+1;
            if(rgb>120)
            {
                long int 准心r = getZZ(getZZ(Self + 0x3DE0) + 0x78) + 0x1558;
                long int 准心g = 准心r + 0x4;
                long int 准心b = 准心g + 0x4;
                int 红=(0+255*rand());
                int 绿=(0+255*rand());
                int 蓝=(0+255*rand());
                writefloat(准心r, 红);//R
                writefloat(准心g, 蓝);//G
                writefloat(准心b, 绿);//B    
            }else
            if(rgb>240)
            {
                rgb=0;
            }
        }


 if(旋转变色)
    {
        for(int a = 0; a < 4; a++)
        {
            long int 特效 = RUI(RUI(RUI(UE4Bss + 0x5A5FF0) + 0x30) + 0x4C8);
            写入F类<float>(RUI(特效 + 0x5A0)+0x10 + 0x40 * a,20);//宽
            写入F类<float>(RUI(特效 + 0x5A0)+0x14 + 0x40 * a,1000);//长
            写入F类<float>(RUI(特效 + 0x5A0)+0x30 ,getfloat(RUI(特效 + 0x5A0)+0x30 ) + 15);
            写入F类<float>(RUI(特效 + 0x5A0)+0x2C ,getfloat(RUI(特效 + 0x5A0)+0x2C ) + 15);//旋转
			写入F类<float>(RUI(特效 + 0x5A0)+0x30 + 0x40 ,getfloat(RUI(特效 + 0x5A0)+0x30 + 0x40 ) + 15);
            写入F类<float>(RUI(特效 + 0x5A0)+0x2C + 0x40 ,getfloat(RUI(特效 + 0x5A0)+0x2C + 0x40 ) + 15);//旋转
			写入F类<float>(RUI(特效 + 0x5A0)+0x30 + 0x40 + 0x40,getfloat(RUI(特效 + 0x5A0)+0x30 + 0x40 + 0x40) + 15);
            写入F类<float>(RUI(特效 + 0x5A0)+0x2C + 0x40 + 0x40,getfloat(RUI(特效 + 0x5A0)+0x2C + 0x40 + 0x40) + 15);//旋转
			写入F类<float>(RUI(特效 + 0x5A0)+0x30 + 0x40 + 0x40 + 0x40,getfloat(RUI(特效 + 0x5A0)+0x30 + 0x40 + 0x40 + 0x40) + 15);
            写入F类<float>(RUI(特效 + 0x5A0)+0x2C + 0x40 + 0x40 + 0x40,getfloat(RUI(特效 + 0x5A0)+0x2C + 0x40 + 0x40 + 0x40) + 15);//旋转
            写入F类<float>(特效 + 0x5D4,rand() % 2);//未爆头
            写入F类<float>(特效 + 0x5D8,rand() % 2);//未爆头
            写入F类<float>(特效 + 0x5DC,rand() % 2);//未爆头
            写入F类<float>(特效 + 0x5E4,rand() % 2);//已爆头
            写入F类<float>(特效 + 0x5E8,rand() % 2);//已爆头
            写入F类<float>(特效 + 0x5EC,rand() % 2);//已爆头
        }
    }


    int totalEnemies = 0, totalBots = 0;

    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localController = 0;



    for (int i = 0; i < Actors.Num(); i++) {
        auto Actor = Actors[i];
        if (isObjectInvalid(Actor))
            continue;

        if (Actor->IsA(ASTExtraPlayerController::StaticClass())) {
            localController = (ASTExtraPlayerController *) Actor;
            break;
        }
    }


    if (localController) {
        for (int i = 0; i < Actors.Num(); i++) {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                if (((ASTExtraPlayerCharacter *) Actor)->PlayerKey == localController->PlayerKey) {
                    localPlayer = (ASTExtraPlayerCharacter *) Actor;
                    break;
                }
            }
        }



        if (localPlayer) {
            if (localPlayer->PartHitComponent) {
                auto ConfigCollisionDistSqAngles = localPlayer->PartHitComponent->ConfigCollisionDistSqAngles;
                auto numAngles = ConfigCollisionDistSqAngles.Num();
                for (int j = numAngles - 1; j >= 0; j--) {
                    int numAnglesIndex = numAngles - j -1;
                    float offset = sin(j* 0.2f + 0.3f)* 2.0f;
                    float baseAngle = numAnglesIndex % 2 == 0 ? 170.0f : -190.0f;
                    ConfigCollisionDistSqAngles[j].Angle = baseAngle + offset;
                    localPlayer->PartHitComponent->ConfigCollisionDistSqAngles = ConfigCollisionDistSqAngles;
                }
            }


            if(概率子追) {
                auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                if (WeaponManagerComponent) {
                    auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;//指针指向类名ASTExtraShootWeapon
                    if (CurrentWeaponReplicated) {
                        ZdDq = CurrentWeaponReplicated->CurBulletNumInClip;
                        ZdMax = CurrentWeaponReplicated->CurMaxBulletNumInOneClip;//获取当前枪管中的子弹数量
                        auto wppp = CurrentWeaponReplicated->GetWeaponID();




                    }
                }


                int 命中数量 = ZdMax * 子追命中率;

                if (概率子追 && ZdDq > 0) {
                    srand((unsigned int)time(NULL));
                    int 第n颗子弹 = 1 + rand() % ZdMax; // 随机生成第n颗子弹
                    if (第n颗子弹 <= 命中数量) {
                        追踪状态 = true;
                    } else {
                        追踪状态 = false;

                    }
                } else {
                    追踪状态 = false;

                }
            }


            if (IsLaunch = true)
            {
                if (追踪&&追踪状态) {
                    auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                    if (WeaponManagerComponent) {
                        auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                        if ((int) propSlot.GetValue() >= 1 && (int) propSlot.GetValue() <= 3) {
                            auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
                            if (CurrentWeaponReplicated) {
                                auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
                                if (ShootWeaponComponent) {
                                    int shoot_event_idx = 169;
                                    auto VTable = (void **) ShootWeaponComponent->VTable;
                                    // CHANGE22222 add lambda function f_mprotect
                                    auto f_mprotect = [](uintptr_t addr, size_t len, int32_t prot) -> int32_t {
                                        static_assert(PAGE_SIZE == 4096);
                                        constexpr size_t page_size = static_cast<size_t>(PAGE_SIZE);
                                        void* start = reinterpret_cast<void*>(addr & -page_size);
                                        uintptr_t end = (addr + len + page_size - 1) & -page_size;
                                        return mprotect(start, end - reinterpret_cast<uintptr_t>(start), prot);
                                    };
                                    if (VTable && (VTable[shoot_event_idx] != shoot_event)) {
                                        orig_shoot_event = decltype(orig_shoot_event)(
                                                               VTable[shoot_event_idx]);
                                        // CHANGE22222 add call of f_mprotect
                                        f_mprotect((uintptr_t)(&VTable[shoot_event_idx]), sizeof(uintptr_t), PROT_READ | PROT_WRITE);
                                        VTable[shoot_event_idx] = (void *) shoot_event;
                                    }
                                }
                            }
                        }
                    }
                    if (自动开火) {
                        if (GetTargetForBT()||GetTargetForBT2()) {
                            localController->bIsPressingFireBtn = true;
                        } else {

                            qwcifqvs86y8fify = true;
                        }
                    }
                }
                IsLaunch = false;
            }
			
			
			if(淫叫)
            {
                g_LocalPlayer->STPlayerController->ClientOnHurt();
            }
			
            if(自动瞄准) {
                ASTExtraPlayerCharacter *Target = NIKE_Aim_Thread();
                if (Target) {
                    FVector targetAimPos;

                    bool triggerOk = false;
                    if (开火) {
                        triggerOk = g_LocalPlayer->bIsWeaponFiring;
                    } else if (开镜) {
                        triggerOk = g_LocalPlayer->bIsGunADS;
                    } else if (开火开镜) {
                        triggerOk = g_LocalPlayer->bIsWeaponFiring || g_LocalPlayer->bIsGunADS;
                    } else triggerOk = true;
                    if (triggerOk) {
                        if (头部) {
                            if(算法 == 0) {
                                targetAimPos=Target->GetBonePos("Head", {});
                            } else if(算法 == 1) {
                                targetAimPos = Target->GetBonePos("Head", {});
                            } else if(算法 == 2) {
                                targetAimPos = Target->GetBonePos("pelvis", {});//锁骨
                            } else if(算法 == 3) { //Config
                                targetAimPos = Target->GetBonePos("calf_l", {});//左小腿
                            } else if(算法 == 4) {
                                targetAimPos = Target->GetBonePos("calf_r", {});//右小腿
                            } else if(算法 == 5) {
                                targetAimPos = Target->GetBonePos("lowerarm_l", {});//左小臂
                            } else if(算法 == 6) {
                                targetAimPos = Target->GetBonePos("lowerarm_r", {});//右小臂
                            } else if(算法 == 7) {
                                targetAimPos = Target->GetBonePos("upperarm_l", {});//左上臂
                            } else if(算法 == 8) {
                                targetAimPos = Target->GetBonePos("upperarm_r", {});//右上臂
                            } else if(算法 == 9) {
                                targetAimPos = Target->GetBonePos("thigh_l", {});//左大腿
                            } else if(算法 == 10) {
                                targetAimPos = Target->GetBonePos("thigh_r", {});//右大腿
                            } else if(算法 == 11) {
                                targetAimPos = Target->GetBonePos("foot_l", {});//左脚
                            } else if(算法 == 12) {
                                targetAimPos = Target->GetBonePos("foot_r", {});//右脚
                            }
                        } else if (身体) {
                            if(算法 == 0) {
                                targetAimPos=Target->GetBonePos("pelvis", {});
                            } else if(算法 == 1) {
                                targetAimPos = Target->GetBonePos("pelvis", {});
                            } else if(算法 == 2) {
                                targetAimPos = Target->GetBonePos("pelvis", {});//锁骨
                            } else if(算法 == 3) { //Config
                                targetAimPos = Target->GetBonePos("calf_l", {});//左小腿
                            } else if(算法 == 4) {
                                targetAimPos = Target->GetBonePos("calf_r", {});//右小腿
                            } else if(算法 == 5) {
                                targetAimPos = Target->GetBonePos("lowerarm_l", {});//左小臂
                            } else if(算法 == 6) {
                                targetAimPos = Target->GetBonePos("lowerarm_r", {});//右小臂
                            } else if(算法 == 7) {
                                targetAimPos = Target->GetBonePos("upperarm_l", {});//左上臂
                            } else if(算法 == 8) {
                                targetAimPos = Target->GetBonePos("upperarm_r", {});//右上臂
                            } else if(算法 == 9) {
                                targetAimPos = Target->GetBonePos("thigh_l", {});//左大腿
                            } else if(算法 == 10) {
                                targetAimPos = Target->GetBonePos("thigh_r", {});//右大腿
                            } else if(算法 == 11) {
                                targetAimPos = Target->GetBonePos("foot_l", {});//左脚
                            } else if(算法 == 12) {
                                targetAimPos = Target->GetBonePos("foot_r", {});//右脚
                            }
                        }
                        auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                        if (WeaponManagerComponent) {
                            auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                            if ((int)propSlot.GetValue() >= 1 && (int)propSlot.GetValue() <= 3) {
                                auto CurrentWeaponReplicated = (ASTExtraShootWeapon *)WeaponManagerComponent->CurrentWeaponReplicated;
                                if (CurrentWeaponReplicated) {
                                    auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
                                    if (ShootWeaponComponent) {
                                        UShootWeaponEntity *ShootWeaponEntityComponent = ShootWeaponComponent->ShootWeaponEntityComponent;
                                        if (ShootWeaponEntityComponent) {
                                            ASTExtraVehicleBase *CurrentVehicle = Target->CurrentVehicle;
                                            if (CurrentVehicle) {
                                                float dist = g_LocalPlayer->GetDistanceTo(Target);
                                                FVector LinearVelocity = CurrentVehicle->ReplicatedMovement.LinearVelocity;
                                                auto timeToTravel = dist / ShootWeaponEntityComponent->BulletRange;
                                                targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(LinearVelocity, timeToTravel*Aim_Vehicle));
                                            } else {
                                                float dist = g_LocalPlayer->GetDistanceTo(Target);

                                                auto timeToTravel = dist / ShootWeaponEntityComponent->BulletRange;

                                                FVector Velocity = Target->GetVelocity();
                                                targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(Velocity,timeToTravel*Aim_Anticipation));
                                            }
                                        }
                                        float dist = g_LocalPlayer->GetDistanceTo(Target);
                                        if (g_LocalPlayer->bIsWeaponFiring) {
                                            targetAimPos.Z -= dist*Aim_PosZ;
                                        }
                                        if (localController) {
                                            auto ControlRotator =  localController->ControlRotation;//内存接口
                                            auto PlayerCameraManage = localController->PlayerCameraManager;
                                            if (PlayerCameraManage) {
                                                auto aimRotation = ToRotator(g_LocalController->PlayerCameraManager->CameraCache.POV.Location,targetAimPos);
                                                if (自动瞄准) {
                                                    aimRotation.Yaw -= ControlRotator.Yaw;
                                                    aimRotation.Pitch -= ControlRotator.Pitch;
                                                    AimAngle(aimRotation);
                                                    ControlRotator.Pitch += aimRotation.Pitch / 自瞄速度;//X轴
                                                    ControlRotator.Yaw += aimRotation.Yaw / 自瞄速度;//Y轴
                                                } else {
                                                    ControlRotator.Yaw = aimRotation.Yaw;
                                                    ControlRotator.Pitch = aimRotation.Pitch;
                                                }
                                                g_LocalController->ControlRotation = ControlRotator;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < Actors.Num(); i++) {
                auto Actor = Actors[i];
                if (isObjectInvalid(Actor))
                    continue;


                if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass()))
                {
                    auto Player = (ASTExtraPlayerCharacter *) Actor;

                    if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass()))
                    {
                        long 绘图 = IM_COL32(50, 222, 50, 255);
                        long PlayerBoxClrCf = IM_COL32(255, 0, 0, 255);
                        long PlayerBoxClrCf2 = IM_COL32(255, 0, 0, 25);



                        long OEXL = ImColor(255,153,0);
                        auto Player = (ASTExtraPlayerCharacter *) Actor;
                        if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                        {

                            OEXL =浅蓝;
                            PlayerBoxClrCf = IM_COL32(255, 255, 255, 255);
                            PlayerBoxClrCf2 = IM_COL32(255, 255, 255, 25);
                        }
                        float Distance = localPlayer->GetDistanceTo(Player) / 100.0f;
                        if (Distance > 500.0f)
                            continue;

                        if (Player->PlayerKey == localController->PlayerKey)
                            continue;

                        if (Player->TeamID == localController->TeamID)
                            continue;

                        if (Player->bDead)
                            continue;

                        if (Player->bEnsure)

                            绘图 = IM_COL32(230, 184, 175, 255);
                        bool IsVisible = localController->LineOfSightTo(Player, {0, 0, 0}, true);
                        int SCOLOR;
                        int SCOLOR2;
                        int SCOLO;
                        if (IsVisible)
                        {
                            SCOLOR = IM_COL32(0, 255, 0, 255);
                            SCOLOR2 = IM_COL32(0, 255, 0, 25);
                            SCOLO = IM_COL32(255, 100, 0, 100);
                        } else {
                            SCOLOR = IM_COL32(255, 0, 0, 255);
                            SCOLOR2 = IM_COL32(255, 0, 0, 25);
                            SCOLO = IM_COL32(0, 0, 0, 100);
                        }
                        int Colorhealth;
                        int healthOutline;
                        if (Player->bEnsure)
                        {
                            totalBots++;
                            Colorhealth = IM_COL32(0, 255, 0, 90);
                            healthOutline = IM_COL32(0, 255, 174, 255);
                        }
                        else
                        {
                            totalEnemies++;
                            Colorhealth = IM_COL32(255, 100, 0, 100);
                            healthOutline = IM_COL32(255, 0, 0, 255);
                        }
                        ///int SCOLOR3;
                        if (Player->bEnsure)
                        {
                            SCOLO = IM_COL32(0, 255, 0, 90);
                        }

                        if (忽略人机)
                            if (Player->bEnsure)
                                continue;
                        float magic_number = (Distance);
                        float mx = (glWidth / 4) / magic_number;

                        float healthLength = glWidth / 17;
                        if (healthLength < mx)
                            healthLength = mx;
                        auto HeadPos = Player->GetBonePos("Head", {});
                        ImVec2 headPosSC;
                        auto RootPos = Player->GetBonePos("Root", {});
                        ImVec2 RootPosSC;
                        auto upper_r = Player->GetBonePos("upperarm_r", {});
                        ImVec2 upper_rPoSC;
                        auto lowerarm_r = Player->GetBonePos("lowerarm_r", {});
                        ImVec2 lowerarm_rPoSC;
                        auto hand_r = Player->GetBonePos("hand_r", {});
                        ImVec2 hand_rPoSC;
                        auto upper_l = Player->GetBonePos("upperarm_l", {});
                        ImVec2 upper_lPoSC;
                        auto lowerarm_l = Player->GetBonePos("lowerarm_l", {});
                        ImVec2 lowerarm_lSC;
                        auto hand_l = Player->GetBonePos("hand_l", {});
                        ImVec2 hand_lPoSC;
                        auto thigh_l = Player->GetBonePos("thigh_l", {});
                        ImVec2 thigh_lPoSC;
                        auto calf_l = Player->GetBonePos("calf_l", {});
                        ImVec2 calf_lPoSC;
                        auto foot_l = Player->GetBonePos("foot_l", {});
                        ImVec2 foot_lPoSC;
                        auto thigh_r = Player->GetBonePos("thigh_r", {});
                        ImVec2 thigh_rPoSC;
                        auto calf_r = Player->GetBonePos("calf_r", {});
                        ImVec2 calf_rPoSC;
                        auto foot_r = Player->GetBonePos("foot_r", {});
                        ImVec2 foot_rPoSC;
                        auto neck_01 = Player->GetBonePos("neck_01", {});
                        ImVec2 neck_01PoSC;
                        auto pelvis = Player->GetBonePos("pelvis", {});
                        ImVec2 pelvisPoSC;

                        if (W2S(HeadPos, (FVector2D *) &headPosSC) &&
                                W2S(upper_r, (FVector2D *) &upper_rPoSC) &&
                                W2S(upper_l, (FVector2D *) &upper_lPoSC) &&
                                W2S(lowerarm_r, (FVector2D *) &lowerarm_rPoSC) &&
                                W2S(hand_r, (FVector2D *) &hand_rPoSC) &&
                                W2S(lowerarm_l, (FVector2D *) &lowerarm_lSC) &&
                                W2S(hand_l, (FVector2D *) &hand_lPoSC) &&
                                W2S(thigh_l, (FVector2D *) &thigh_lPoSC) &&
                                W2S(calf_l, (FVector2D *) &calf_lPoSC) &&
                                W2S(foot_l, (FVector2D *) &foot_lPoSC) &&
                                W2S(thigh_r, (FVector2D *) &thigh_rPoSC) &&
                                W2S(calf_r, (FVector2D *) &calf_rPoSC) &&
                                W2S(foot_r, (FVector2D *) &foot_rPoSC) &&
                                W2S(neck_01, (FVector2D *) &neck_01PoSC) &&
                                W2S(pelvis, (FVector2D *) &pelvisPoSC) &&
                                W2S(RootPos, (FVector2D *) &RootPosSC))
                        {
//=======𝐌𝐚𝐝𝐞 𝐁𝐲 𝐂𝐨𝐧𝐟𝐢𝐠 𝐊𝐢𝐧𝐠   [ 𝐁𝐬𝐝𝐤 𝐈𝐦𝐠𝐮𝐢 𝐄𝐱𝐩𝐞𝐫𝐭 𝐁𝐨𝐥𝐭𝐞 ]====== //
                            if (绘制狗子) {

                                FVector2D 狗子坐标;
                                auto RootComponent = Actor->RootComponent;
                                if (!RootComponent)
                                    continue;
                                float Distance = Actor->GetDistanceTo(localPlayer) / 100.f;
                                int CurHP = (int) std::max(0, std::min((int) localPlayer->Health, (int) localPlayer->HealthMax));//数量
                                int MaxHP = (int) localPlayer->HealthMax;
                                if (localPlayer->bDead)
                                    continue;
                                if (Distance > 500)
                                    continue;
                                if (W2S(Actor->K2_GetActorLocation(), &狗子坐标)) {
                                    if (localPlayer->Health == 0.0f && !localPlayer->bDead) {
                                        float boxWidth = density / 1.8f;
                                        float boxHeight = boxWidth * 0.19f;
                                        std::string s;
                                        s += "\n死亡";
                                        绘制加粗文本2(density / 25.0f,狗子坐标.X, 狗子坐标.Y, 黄色,黑色,s.c_str());
                                        CurHP = localPlayer->NearDeathBreath;
                                        if (localPlayer->NearDeatchComponent) {
                                            MaxHP = localPlayer->NearDeatchComponent->BreathMax;
                                        }
                                    }
                                    std::string classname = Actor->GetName();
                                    if (classname.find("AIMob_PatrolDog_C") != std::string::npos) {
                                        std::string s =  "机械狗";
                                        s += "[";
                                        s += std::to_string((int) Distance);
                                        s += "米]\n";
                                        s += "血量:";
                                        s += std::to_string((int)CurHP);
                                        绘制加粗文本2(density / 25.0f,狗子坐标.X, 狗子坐标.Y, 黄色,黑色,s.c_str());
                                    }
                                    if (classname.find("BPPawn_Library_C") != std::string::npos) {
                                        std::string s =  "大马猴";
                                        s += "[";
                                        s += std::to_string((int) Distance);
                                        s += "米]\n";
                                        s += "血量:";
                                        s += std::to_string((int)CurHP);
                                        绘制加粗文本2(density / 25.0f,狗子坐标.X, 狗子坐标.Y, 黄色,黑色,s.c_str());
                                    }
                                    if (classname.find("BPPAWn_HungerH_C") != std::string::npos) {
                                        std::string s =  "辐射狗";
                                        s += "[";
                                        s += std::to_string((int) Distance);
                                        s += "米]\n";
                                        s += "血量:";
                                        s += std::to_string((int)CurHP);
                                        绘制加粗文本2(density / 25.0f,狗子坐标.X, 狗子坐标.Y, 黄色,黑色,s.c_str());
                                    }
                                    if (classname.find("BPPawn_HungerB_C") != std::string::npos) {
                                        std::string s =  "辐射狗(大)";
                                        s += "[";
                                        s += std::to_string((int) Distance);
                                        s += "米]\n";
                                        s += "血量:";
                                        s += std::to_string((int)CurHP);
                                        绘制加粗文本2(density / 25.0f,狗子坐标.X, 狗子坐标.Y, 黄色,黑色,s.c_str());
                                    }
                                    if (classname.find("BPPawn_Watcher_C") != std::string::npos) {
                                        std::string s =  "观察者";
                                        s += "[";
                                        s += std::to_string((int) Distance);
                                        s += "米]\n";
                                        s += "血量:";
                                        s += std::to_string((int)CurHP);
                                        绘制加粗文本2(density / 25.0f,狗子坐标.X, 狗子坐标.Y, 黄色,黑色,s.c_str());
                                    }
                                    if (classname.find("BPPawn_VenomVariant_C") != std::string::npos) {
                                        std::string s =  "毒液变异体";
                                        s += "[";
                                        s += std::to_string((int) Distance);
                                        s += "米]\n";
                                        s += "血量:";
                                        s += std::to_string((int)CurHP);
                                        绘制加粗文本2(density / 25.0f,狗子坐标.X, 狗子坐标.Y, 黄色,黑色,s.c_str());
                                    }
                                    if (classname.find("BPPawn_BurningVariant_C") != std::string::npos) {
                                        std::string s =  "燃烧变异体";
                                        s += "[";
                                        s += std::to_string((int) Distance);
                                        s += "米]\n";
                                        s += "血量:";
                                        s += std::to_string((int)CurHP);
                                        绘制加粗文本2(density / 25.0f,狗子坐标.X, 狗子坐标.Y, 黄色,黑色,s.c_str());
                                    }
                                }
                            }
                            if (安全) {
                                if (头部) {
                                    if (Distance < 30) {
                                        头部1 = true;
                                        头部2 = false;
                                    } else if (Distance > 30) {
                                        头部1 = false;
                                        头部2 = true;
                                    }
                                }
                            }
                            if (线条) {
                                int xt1 =ImColor(255, 0, 0);  //没漏
                                int xt2 = ImColor(102,250,166);//露出
                                int rjxt =ImColor(255, 255, 255);  //没漏
                                bool Visble = false;
                                if (Player->bEnsure) {
                                    if(!localController->LineOfSightTo(localController->PlayerCameraManager, neck_01, false))
                                    {
                                        Visble = true;

                                        draw->AddLine({(float) glWidth / 2, 100}, {headPosSC.x, headPosSC.y - 30},rjxt, {1.5f});


                                    } else
                                        draw->AddLine({(float) glWidth / 2, 100}, {headPosSC.x, headPosSC.y - 30},xt2, {1.5f});

                                } else {
                                    if(!localController->LineOfSightTo(localController->PlayerCameraManager, neck_01, false))
                                    {
                                        Visble = true;

                                        draw->AddLine({(float) glWidth / 2, 100}, {headPosSC.x, headPosSC.y - 30},xt1, {1.5f});


                                    } else
                                        draw->AddLine({(float) glWidth / 2, 100}, {headPosSC.x, headPosSC.y - 30},xt2, {1.5f});
                                }

                            }





                        }

                        if (骨骼)
                        {
                            int SCOLOR25 =ImColor(255, 255, 255);  //没漏
                            int SCOLOR23 =ImColor(255, 0, 0);  //没漏

                            int SCOLOR24 = ImColor(102,250,166);//露出

                            bool Visble = false;
                            float boxWidth = 7.f- Distance * 0.03;

                            //          if (Config.PlayerESP.Skeleton) {
                            if (Player->bEnsure)    {
                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, neck_01, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { upper_rPoSC.x, upper_rPoSC.y }, neck_01PoSC, SCOLOR25,1.2f );


                                } else
                                    draw->AddLine( { upper_rPoSC.x, upper_rPoSC.y }, neck_01PoSC, SCOLOR24,1.2f );



                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, neck_01, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { upper_lPoSC.x, upper_lPoSC.y }, neck_01PoSC, SCOLOR25,1.2f );

                                } else
                                    draw->AddLine( { upper_lPoSC.x, upper_lPoSC.y }, neck_01PoSC, SCOLOR24,1.2f );





                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, lowerarm_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { upper_rPoSC.x, upper_rPoSC.y }, lowerarm_rPoSC,SCOLOR25, 1.2f );


                                } else
                                    draw->AddLine( { upper_rPoSC.x, upper_rPoSC.y }, lowerarm_rPoSC,SCOLOR24, 1.2f );






                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, hand_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { lowerarm_rPoSC.x, lowerarm_rPoSC.y }, hand_rPoSC,SCOLOR25, 1.2f );


                                } else
                                    draw->AddLine( { lowerarm_rPoSC.x, lowerarm_rPoSC.y }, hand_rPoSC,SCOLOR24, 1.2f );


                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, lowerarm_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { upper_lPoSC.x, upper_lPoSC.y }, lowerarm_lSC, SCOLOR25,1.2f );

                                } else
                                    draw->AddLine( { upper_lPoSC.x, upper_lPoSC.y }, lowerarm_lSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, hand_l, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { lowerarm_lSC.x, lowerarm_lSC.y }, hand_lPoSC, SCOLOR25,1.2f );
                                } else
                                    draw->AddLine( { lowerarm_lSC.x, lowerarm_lSC.y }, hand_lPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, thigh_l, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { thigh_rPoSC.x, thigh_rPoSC.y }, thigh_lPoSC, SCOLOR25,1.2f );
                                } else
                                    draw->AddLine( { thigh_rPoSC.x, thigh_rPoSC.y }, thigh_lPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, calf_l, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { thigh_lPoSC.x, thigh_lPoSC.y }, calf_lPoSC, SCOLOR25,1.2f );
                                } else
                                    draw->AddLine( { thigh_lPoSC.x, thigh_lPoSC.y }, calf_lPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, foot_l, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { calf_lPoSC.x, calf_lPoSC.y }, foot_lPoSC, SCOLOR25,1.2f );
                                } else
                                    draw->AddLine( { calf_lPoSC.x, calf_lPoSC.y }, foot_lPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, calf_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { thigh_rPoSC.x, thigh_rPoSC.y }, calf_rPoSC, SCOLOR25,1.2f );
                                } else
                                    draw->AddLine( { thigh_rPoSC.x, thigh_rPoSC.y }, calf_rPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, foot_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { calf_rPoSC.x, calf_rPoSC.y }, foot_rPoSC, SCOLOR25,1.2f );
                                } else
                                    draw->AddLine( { calf_rPoSC.x, calf_rPoSC.y }, foot_rPoSC, SCOLOR24,1.2f );
                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, pelvis, false))
                                {
                                    Visble = true;
                                    draw->AddLine( { neck_01PoSC.x, neck_01PoSC.y }, pelvisPoSC, SCOLOR25,1.2f );
                                } else
                                    draw->AddLine( { neck_01PoSC.x, neck_01PoSC.y }, pelvisPoSC, SCOLOR24,1.2f );
                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, HeadPos, false))
                                {
                                    Visble = true;
                                    //		boxwidth = 1.7f - 0.003*Distance
                                    draw->AddLine( { neck_01PoSC.x, neck_01PoSC.y }, headPosSC, SCOLOR25,1.2f );
                                    //	draw->AddCircle({headPosSC.x, headPosSC.y}, boxWidth, SCOLOR25, 1000000, 1.0f);
                                } else
                                    draw->AddLine( { neck_01PoSC.x, neck_01PoSC.y }, headPosSC, SCOLOR24,1.2f );

                            } else {
                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, neck_01, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { upper_rPoSC.x, upper_rPoSC.y }, neck_01PoSC, SCOLOR23,1.2f );


                                } else
                                    draw->AddLine( { upper_rPoSC.x, upper_rPoSC.y }, neck_01PoSC, SCOLOR24,1.2f );



                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, neck_01, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { upper_lPoSC.x, upper_lPoSC.y }, neck_01PoSC, SCOLOR23,1.2f );

                                } else
                                    draw->AddLine( { upper_lPoSC.x, upper_lPoSC.y }, neck_01PoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, lowerarm_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { upper_rPoSC.x, upper_rPoSC.y }, lowerarm_rPoSC,SCOLOR23, 1.2f );


                                } else
                                    draw->AddLine( { upper_rPoSC.x, upper_rPoSC.y }, lowerarm_rPoSC,SCOLOR24, 1.2f );


                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, hand_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { lowerarm_rPoSC.x, lowerarm_rPoSC.y }, hand_rPoSC,SCOLOR23, 1.2f );


                                } else
                                    draw->AddLine( { lowerarm_rPoSC.x, lowerarm_rPoSC.y }, hand_rPoSC,SCOLOR24, 1.2f );






                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, lowerarm_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { upper_lPoSC.x, upper_lPoSC.y }, lowerarm_lSC, SCOLOR23,1.2f );

                                } else
                                    draw->AddLine( { upper_lPoSC.x, upper_lPoSC.y }, lowerarm_lSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, hand_l, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { lowerarm_lSC.x, lowerarm_lSC.y }, hand_lPoSC, SCOLOR23,1.2f );
                                } else
                                    draw->AddLine( { lowerarm_lSC.x, lowerarm_lSC.y }, hand_lPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, thigh_l, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { thigh_rPoSC.x, thigh_rPoSC.y }, thigh_lPoSC, SCOLOR23,1.2f );
                                } else
                                    draw->AddLine( { thigh_rPoSC.x, thigh_rPoSC.y }, thigh_lPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, calf_l, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { thigh_lPoSC.x, thigh_lPoSC.y }, calf_lPoSC, SCOLOR23,1.2f );
                                } else
                                    draw->AddLine( { thigh_lPoSC.x, thigh_lPoSC.y }, calf_lPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, foot_l, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { calf_lPoSC.x, calf_lPoSC.y }, foot_lPoSC, SCOLOR23,1.2f );
                                } else
                                    draw->AddLine( { calf_lPoSC.x, calf_lPoSC.y }, foot_lPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, calf_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { thigh_rPoSC.x, thigh_rPoSC.y }, calf_rPoSC, SCOLOR23,1.2f );
                                } else
                                    draw->AddLine( { thigh_rPoSC.x, thigh_rPoSC.y }, calf_rPoSC, SCOLOR24,1.2f );

                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, foot_r, false))
                                {
                                    Visble = true;

                                    draw->AddLine( { calf_rPoSC.x, calf_rPoSC.y }, foot_rPoSC, SCOLOR23,1.2f );
                                } else
                                    draw->AddLine( { calf_rPoSC.x, calf_rPoSC.y }, foot_rPoSC, SCOLOR24,1.2f );
                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, pelvis, false))
                                {
                                    Visble = true;
                                    draw->AddLine( { neck_01PoSC.x, neck_01PoSC.y }, pelvisPoSC, SCOLOR23,1.2f );
                                } else
                                    draw->AddLine( { neck_01PoSC.x, neck_01PoSC.y }, pelvisPoSC, SCOLOR24,1.2f );
                                if(!localController->LineOfSightTo(localController->PlayerCameraManager, HeadPos, false))
                                {
                                    Visble = true;
                                    //		boxwidth = 1.7f - 0.003*Distance
                                    draw->AddLine( { neck_01PoSC.x, neck_01PoSC.y }, headPosSC, SCOLOR23,1.2f );
                                    //	draw->AddCircle({headPosSC.x, headPosSC.y}, boxWidth, SCOLOR23, 1000000, 1.0f);
                                } else
                                    draw->AddLine( { neck_01PoSC.x, neck_01PoSC.y }, headPosSC, SCOLOR24,1.2f );
                            }


                        }




                        if (名字) {
                            std::string s;

                            if (Player->bEnsure) {

                                s += "bot";
                            } else {
                                s += Player->PlayerName.ToString();
                            }
                            auto textSize = ImGui::CalcTextSize2(s.c_str(), 0, 15);
                            draw->AddText(NULL, ((float) density / 25.0f), {RootPosSC.x - (textSize.x / 2), RootPosSC.y+2.0f}, IM_COL32(255, 255, 255, 255), s.c_str());
                        }

                        if (血量1) {
                            int CurHP = (int) std::max(0, std::min((int) Player->Health, (int) Player->HealthMax));
                            int MaxHP = (int) Player->HealthMax;


                            float boxWidth = density / 8.5f;
                            boxWidth -= std::min(((boxWidth / 2) / 700.0f) * Distance, boxWidth / 2);
                            float boxHeight = boxWidth * 0.195f;


                            ImVec2 vStart = {headPosSC.x - (boxWidth / 2), headPosSC.y - (boxHeight * 2.5f)};

                            ImVec2 vEndFilled = {vStart.x + (CurHP * boxWidth / MaxHP), vStart.y + boxHeight};
                            ImVec2 vEndRect = {vStart.x + boxWidth, vStart.y + boxHeight};

                            draw->AddRectFilled(vStart, vEndFilled, ImColor(102,250,166), 0.0f);
                            draw->AddRect(vStart, vEndRect, IM_COL32(0, 0, 0, 255), 0.0f);


                        }
                        
                        
                        if (追踪 &&LockObj &&漏打) {

                            float Distance = localPlayer->GetDistanceTo(LockObj) / 100.0f;
                            std::string 玩家名字 = LockObj->PlayerName.ToString();
                            std::string xsnb;
                            xsnb += "警告已漏：";
                            xsnb += 玩家名字;
                            xsnb += "【";
                            xsnb += std::to_string((int)Distance);
                            xsnb += "M】";
                            绘制字体描边(27.0f,glWidth/2-430,205,浅蓝, xsnb.c_str());
                        }
                        
                        
                        if (血量2) {
                            ImColor 血量颜色1;
                            if (Player->Health >=80) {
                                血量颜色1 =浅粉;
                            } else {
                                血量颜色1 =空白;
                            }
                            ImColor 血量颜色2;
                            if (Player->Health >=60) {
                                血量颜色2 =浅粉;
                            } else {
                                血量颜色2 =空白;
                            }
                            ImColor 血量颜色3;
                            if (Player->Health >=40) {
                                血量颜色3 =浅粉;
                            } else {
                                血量颜色3 =空白;
                            }
                            ImColor 血量颜色4;
                            if (Player->Health >=20) {
                                血量颜色4 =浅粉;
                            } else {
                                血量颜色4 =空白;
                            }
                            ImColor 血量颜色5;
                            if (Player->Health !=0) {
                                血量颜色5 =浅粉;
                            } else {
                                血量颜色5 =空白;
                            }
                            std::string duo;//线程
                            draw->AddRectFilled({headPosSC.x - 35, headPosSC.y- 7}, {headPosSC.x- 35+0.8f+14, headPosSC.y- 13},血量颜色5,0);//血量20
                            draw->AddRectFilled({headPosSC.x - 20, headPosSC.y- 7}, {headPosSC.x- 20+0.8f+14, headPosSC.y- 13},血量颜色4,0);//血量40
                            draw->AddRectFilled({headPosSC.x -5, headPosSC.y- 7}, {headPosSC.x-5 +0.8f+14, headPosSC.y- 13},血量颜色3,0); //血量60
                            draw->AddRectFilled({headPosSC.x +10, headPosSC.y- 7}, {headPosSC.x+10 +0.8f+14, headPosSC.y- 13},血量颜色2,0); //血量80
                            draw->AddRectFilled({headPosSC.x +25, headPosSC.y- 7}, {headPosSC.x+25 +0.8f+14, headPosSC.y- 13},血量颜色1,0); //血量80
                            draw->AddRect({headPosSC.x - 35, headPosSC.y- 7}, {headPosSC.x- 35+0.8f+14, headPosSC.y- 13},黑色,0,50); //血量20
                            draw->AddRect({headPosSC.x -  20, headPosSC.y- 7}, {headPosSC.x- 20+0.8f+14, headPosSC.y- 13},黑色,0,50); //血量40
                            draw->AddRect({headPosSC.x- 5, headPosSC.y- 7}, {headPosSC.x-5 +0.8f+14, headPosSC.y- 13},黑色,0,50);//血量60
                            draw->AddRect({headPosSC.x +10, headPosSC.y- 7}, {headPosSC.x+10 +0.8f+14, headPosSC.y- 13},黑色,0,50);//血量80
                            draw->AddRect({headPosSC.x +25, headPosSC.y- 7}, {headPosSC.x+25 +0.8f+14, headPosSC.y- 13},黑色,0,50);//血量80

                        }



                        if (距离) {
                            float boxWidth = density / 1.6f;
                            boxWidth -= std::min(((boxWidth / 2) / 00.0f) * Distance,boxWidth / 2);
                            float boxHeight = boxWidth * 0.33f;
                            std::string s;
                            s += "     ";
                            s += std::to_string((int) Distance);
                            s += "M";

                            auto textSize = ImGui::CalcTextSize2(s.c_str(), 0, 22);
                            draw->AddText(NULL, ((float) density / 25.0f), {RootPosSC.x - (textSize.x / 2), RootPosSC.y+18.0f}, IM_COL32(255, 255, 255, 255), s.c_str());
                        }

                    }

                }

                if (盒子)
                         {
                    if (Actor->IsA(APickUpListWrapperActor::StaticClass())) {
                        auto LootBox = (APickUpListWrapperActor *) Actor;
                        auto RootComponent = Actor->RootComponent;
                        if (!RootComponent)
                            continue;
                        float Distance = LootBox->GetDistanceTo(localPlayer) / 100.f;

                        FVector2D lootboxPos;
                        if (W2S(LootBox->K2_GetActorLocation(), &lootboxPos)) {
                            std::string s = "Box";
                            s += "[";
                            s += std::to_string((int) Distance);
                            s += "M]";

                            draw->AddText(NULL, ((float) density / 22.0f),
                            {lootboxPos.X, lootboxPos.Y},
                            IM_COL32(102,250,166, 255), s.c_str());
                        }
                    }
                }

                if (车辆)
                {
                    if (Actors[i]->IsA(ASTExtraVehicleBase::StaticClass()))
                    {
                        auto Vehicle = (ASTExtraVehicleBase *) Actors[i];

                        if (!Vehicle->Mesh)
                            continue;

                        float Distance = Vehicle->GetDistanceTo(localPlayer) / 100.f;

                        FVector2D vehiclePos;
                        if (W2S(Vehicle->K2_GetActorLocation(), &vehiclePos)) {
                            std::string s = GetVehicleName(Vehicle);
                            s += " [";
                            s += std::to_string((int) Distance);
                            s += "m]";

                            draw->AddText(NULL, ((float) density / 30.0f),
                            {vehiclePos.X, vehiclePos.Y},
                            IM_COL32(102,250,166, 255), s.c_str());
                        }
                    }
                }




            }

        }
        g_LocalController = localController;
        g_LocalPlayer = localPlayer;
        std::string s;
        if (totalEnemies + totalBots > 0) {
            s = std::to_string((int) totalEnemies + totalBots);
        } else {
            s += "0";
        }



 // if(追踪线){

        draw->AddRectFilled(ImVec2(glWidth / 2 - 18.f, 100), ImVec2(glWidth / 2 + 18, 70), IM_COL32(255, 255, 255, 255), 0.0f);


        auto textSize = ImGui::CalcTextSize2(s.c_str(), 0, ((float) density / 31.0f));
        draw->AddText(NULL, ((float) density / 16.5f), {((float) glWidth / 2) - (textSize.x / 1), 71}, IM_COL32(128, 0, 250, 204), s.c_str());

                         
    }


    if(水印)
    {
    } else {
        std::string credit = "@liangmoyyds";
        auto textSize = ImGui::CalcTextSize2(credit.c_str(), 0, ((float) density / 14.0f));
        draw->AddText(NULL, ((float) density / 14.0f), {((float) glWidth / 2) - (textSize.x / 2), 35}, IM_COL32(255, 0, 0, 255), credit.c_str());
        draw->AddText(NULL, ((float) density / 14.0f), {((float) glWidth / 2) - (textSize.x / 2), 35}, IM_COL32(255, 0, 0, 100), credit.c_str());

    }



    if (追踪) {//追踪圈
        if (配置1) {
            draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), 范围, 黄色, 0, 1.5f);
        } else {

        }
    }

  
  if (追踪线){
ASTExtraPlayerCharacter *Target = GetTargetForBT();

long PlayerAimLineColor = IM_COL32(255, 255, 255, 255);
if (Target) {
FVector HEAD = Target->GetBonePos("Head", {});

ImVec2 HeadPosSC;
if (W2S(HEAD, (FVector2D *)&HeadPosSC)) {


draw->AddLine({(float) glWidth / 2,  (float) (glHeight / 2)}, HeadPosSC,
黄色, 2.5f);

}
}
  }

    if (自动瞄准) {//追踪圈

        draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), 范围, 白色, 0, 1.5f);

    }
}

// ======================================================================== //// ======================================================================== //

std::string getClipboardText() {
    if (!g_App)
        return "";

    auto activity = g_App->activity;
    if (!activity)
        return "";

    auto vm = activity->vm;
    if (!vm)
        return "";

    auto object = activity->clazz;
    if (!object)
        return "";

    std::string result;

    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);
    {
        auto ContextClass = env->FindClass("android/content/Context");
        auto getSystemServiceMethod = env->GetMethodID(ContextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");

        auto str = env->NewStringUTF("clipboard");
        auto clipboardManager = env->CallObjectMethod(object, getSystemServiceMethod, str);
        env->DeleteLocalRef(str);

        auto ClipboardManagerClass = env->FindClass("android/content/ClipboardManager");
        auto getText = env->GetMethodID(ClipboardManagerClass, "getText", "()Ljava/lang/CharSequence;");

        auto CharSequenceClass = env->FindClass("java/lang/CharSequence");
        auto toStringMethod = env->GetMethodID(CharSequenceClass, "toString", "()Ljava/lang/String;");

        auto text = env->CallObjectMethod(clipboardManager, getText);
        if (text) {
            str = (jstring) env->CallObjectMethod(text, toStringMethod);
            result = env->GetStringUTFChars(str, 0);
            env->DeleteLocalRef(str);
            env->DeleteLocalRef(text);
        }

        env->DeleteLocalRef(CharSequenceClass);
        env->DeleteLocalRef(ClipboardManagerClass);
        env->DeleteLocalRef(clipboardManager);
        env->DeleteLocalRef(ContextClass);
    }
    vm->DetachCurrentThread();

    return result;
}

const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(/*android/content/Context*/ StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass, /*getContentResolver*/ StrEnc("E8X\\7r7ys_Q%JS+L+~", "\x22\x5D\x2C\x1F\x58\x1C\x43\x1C\x1D\x2B\x03\x40\x39\x3C\x47\x3A\x4E\x0C", 18).c_str(), /*()Landroid/content/ContentResolver;*/ StrEnc("8^QKmj< }5D:9q7f.BXkef]A*GYLNg}B!/L", "\x10\x77\x1D\x2A\x03\x0E\x4E\x4F\x14\x51\x6B\x59\x56\x1F\x43\x03\x40\x36\x77\x28\x0A\x08\x29\x24\x44\x33\x0B\x29\x3D\x08\x11\x34\x44\x5D\x77", 35).c_str());
    jclass settingSecureClass = env->FindClass(/*android/provider/Settings$Secure*/ StrEnc("T1yw^BCF^af&dB_@Raf}\\FS,zT~L(3Z\"", "\x35\x5F\x1D\x05\x31\x2B\x27\x69\x2E\x13\x09\x50\x0D\x26\x3A\x32\x7D\x32\x03\x09\x28\x2F\x3D\x4B\x09\x70\x2D\x29\x4B\x46\x28\x47", 32).c_str());
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, /*getString*/ StrEnc("e<F*J5c0Y", "\x02\x59\x32\x79\x3E\x47\x0A\x5E\x3E", 9).c_str(), /*(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;*/ StrEnc("$6*%R*!XO\"m18o,0S!*`uI$IW)l_/_knSdlRiO1T`2sH|Ouy__^}%Y)JsQ:-\"(2_^-$i{?H", "\x0C\x7A\x4B\x4B\x36\x58\x4E\x31\x2B\x0D\x0E\x5E\x56\x1B\x49\x5E\x27\x0E\x69\x0F\x1B\x3D\x41\x27\x23\x7B\x09\x2C\x40\x33\x1D\x0B\x21\x5F\x20\x38\x08\x39\x50\x7B\x0C\x53\x1D\x2F\x53\x1C\x01\x0B\x36\x31\x39\x46\x0C\x15\x43\x2B\x05\x30\x15\x41\x43\x46\x55\x70\x0D\x59\x56\x00\x15\x58\x73", 71).c_str());

    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj, env->NewStringUTF(/*android_id*/ StrEnc("ujHO)8OfOE", "\x14\x04\x2C\x3D\x46\x51\x2B\x39\x26\x21", 10).c_str()));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass(/*android/os/Build*/ StrEnc("m5I{GKGWBP-VOxkA", "\x0C\x5B\x2D\x09\x28\x22\x23\x78\x2D\x23\x02\x14\x3A\x11\x07\x25", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, /*MODEL*/ StrEnc("|}[q:", "\x31\x32\x1F\x34\x76", 5).c_str(), /*Ljava/lang/String;*/ StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass(/*android/os/Build*/ StrEnc("0iW=2^>0zTRB!B90", "\x51\x07\x33\x4F\x5D\x37\x5A\x1F\x15\x27\x7D\x00\x54\x2B\x55\x54", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, /*BRAND*/ StrEnc("@{[FP", "\x02\x29\x1A\x08\x14", 5).c_str(), /*Ljava/lang/String;*/ StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(/*android/content/Context*/ StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getPackageNameId = env->GetMethodID(contextClass, /*getPackageName*/ StrEnc("YN4DaP)!{wRGN}", "\x3E\x2B\x40\x14\x00\x33\x42\x40\x1C\x12\x1C\x26\x23\x18", 14).c_str(), /*()Ljava/lang/String;*/ StrEnc("VnpibEspM(b]<s#[9cQD", "\x7E\x47\x3C\x03\x03\x33\x12\x5F\x21\x49\x0C\x3A\x13\x20\x57\x29\x50\x0D\x36\x7F", 20).c_str());

    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass(/*java/util/UUID*/ StrEnc("B/TxJ=3BZ_]SFx", "\x28\x4E\x22\x19\x65\x48\x47\x2B\x36\x70\x08\x06\x0F\x3C", 14).c_str());

    auto len = strlen(uuid);

    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);

    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass, /*nameUUIDFromBytes*/ StrEnc("P6LV|'0#A+zQmoat,", "\x3E\x57\x21\x33\x29\x72\x79\x67\x07\x59\x15\x3C\x2F\x16\x15\x11\x5F", 17).c_str(), /*([B)Ljava/util/UUID;*/ StrEnc("sW[\"Q[W3,7@H.vT0) xB", "\x5B\x0C\x19\x0B\x1D\x31\x36\x45\x4D\x18\x35\x3C\x47\x1A\x7B\x65\x7C\x69\x3C\x79", 20).c_str());
    jmethodID toStringMethod = env->GetMethodID(uuidClass, /*toString*/ StrEnc("2~5292eW", "\x46\x11\x66\x46\x4B\x5B\x0B\x30", 8).c_str(), /*()Ljava/lang/String;*/ StrEnc("P$BMc' #j?<:myTh_*h0", "\x78\x0D\x0E\x27\x02\x51\x41\x0C\x06\x5E\x52\x5D\x42\x2A\x20\x1A\x36\x44\x0F\x0B", 20).c_str());

    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}
EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);

EGLBoolean _eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    if (glWidth <= 0 || glHeight <= 0)
        return orig_eglSwapBuffers(dpy, surface);

    if (!g_App)
        return orig_eglSwapBuffers(dpy, surface);

    screenWidth = ANativeWindow_getWidth(g_App->window);
    screenHeight = ANativeWindow_getHeight(g_App->window);
    density = AConfiguration_getDensity(g_App->config);




    if (!initImGui) {
IMGUI_CHECKVERSION();
ImGui::CreateContext();
ImGuiIO& io = ImGui::GetIO();
io.IniFilename = NULL;
ImGui::StyleColorsLight();
ImGui_ImplOpenGL3_Init("#version 300 es");
ImFontConfig font_cfg;
font_cfg.SizePixels = 22.0f;
io.Fonts->AddFontFromMemoryTTF((void*)font_v, font_v_size, 29.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
io.Fonts->AddFontDefault(&font_cfg);
ImGuiStyle *style = &ImGui::GetStyle();
style->GrabRounding = 10;
style->ScrollbarRounding = 5; //右侧滚动条 圆角
style->ScrollbarSize = 25; //右侧滚动条 大小
style->WindowRounding = 5; //窗体边框圆角
style->FrameRounding =  5; //窗体圆角
style->GrabMinSize = 10; //滑块宽度
style->WindowTitleAlign = ImVec2(0.5, 0.5); // 设置标题居中
ImGui::GetStyle().ScaleAllSizes(1.0f);//Ui内大小
//luffy_thread.detach();

        io.Fonts->AddFontFromMemoryTTF((void *)FontData, FontSize, 22.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
        ImFontConfig cfg;

        cfg.SizePixels = ((float) density / 25.0f);
        io.Fonts->AddFontDefault(&cfg);


        initImGui = true;
    }




    ImGuiIO &io = ImGui::GetIO();

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
    ImGui::NewFrame();
    DrawESP(ImGui::GetBackgroundDrawList(),glWidth, glHeight);
    ImGui::SetNextWindowSize(ImVec2((float) glWidth * 0.33f, (float) //ui左右长度
                                    glHeight * 0.60f), ImGuiCond_Once);//ui上下长度
    char buf[128];
    sprintf(buf, ("凉墨全火追踪 %.2f FPS ###AnimatedTitle"), (io.Framerate), ImGui::GetFrameCount());

    if (ImGui::Begin(buf))
    {
        if (ImGui::BeginChild("##左侧菜单标题", ImVec2(135, -1), false, ImGuiWindowFlags_NoScrollbar));
        {
            if (ImGui::Button("绘制", ImVec2(130, 50)))
            {
                绘制控件=true;
                追踪控件=false;
                自瞄控件=false;
                设置控件=false;
                功能控件=false;
            }
            if (ImGui::Button("追踪", ImVec2(130, 50)))
            {
                绘制控件=false;
                追踪控件=true;
                自瞄控件=false;
                设置控件=false;
                功能控件=false;
            }

            if (ImGui::Button("功能", ImVec2(130, 50)))
            {
                绘制控件=false;
                追踪控件=false;
                设置控件=false;
                自瞄控件=true;
                功能控件=false;
            }
            if (ImGui::Button("设置", ImVec2(130, 50)))
            {
                绘制控件=false;
                追踪控件=false;
                设置控件=true;
                自瞄控件=false;
                功能控件=false;
            }
            ImGui::EndChild();
            ImGui::SameLine();



            if (ImGui::BeginChild("左侧标题", ImVec2(0, 0), false, ImGuiTabBarFlags_FittingPolicyScroll))
            {
                if(绘制控件) {
                    ImGui::Checkbox("线条", &线条);
                    ImGui::SameLine();
                    ImGui::Checkbox("骨骼", &骨骼);

                    ImGui::Checkbox("血量1", &血量1);
                    ImGui::SameLine();
                    ImGui::Checkbox("血量2", &血量2);

                    ImGui::Checkbox("名字", &名字);
                    ImGui::SameLine();
                    ImGui::Checkbox("距离", &距离);

                    ImGui::Checkbox("车辆", &车辆);
                    ImGui::SameLine();
                    ImGui::Checkbox("盒子", &盒子);

                    ImGui::Checkbox("隐机", &忽略人机);
                    ImGui::SameLine();
                    ImGui::Checkbox("狗子", &绘制狗子);
                }
                ImGui::EndChild();
            }

            if (ImGui::BeginChild("左侧标题", ImVec2(0, 0), false, ImGuiTabBarFlags_FittingPolicyScroll))
            {
                if(追踪控件) {
                    配置1 = true;
                    ImGui::Checkbox("子弹追踪", &追踪);
                    ImGui::SameLine();
                    ImGui::Checkbox("追踪射线", &追踪线);
                    ImGui::Checkbox("平滑自瞄", &自动瞄准);
                    if(追踪)
                    {
                        ImGui::Checkbox("概率模式", &概率子追);
                        ImGui::SliderFloat("范围",&范围, 0.0f, 1314.0f);
                        if (概率子追) {
                            ImGui::SliderFloat("概率调节",&子追命中率, 0.0f, 1.0f);
                        }
                    }

                    if(自动瞄准)
                    {
                        static int 激活 = 3;
                        ImGui::RadioButton("开火", &激活,1);
                        ImGui::SameLine();
                        ImGui::RadioButton("开镜", &激活,2);
                        ImGui::SameLine();
                        ImGui::RadioButton("开火开镜", &激活,3);
                        switch (激活) {
                        case 1:
                            开火 = true;
                            开镜 = false;
                            开火开镜 = false;
                            break;
                        case 2:
                            开火 = false;
                            开镜 = true;
                            开火开镜 = false;
                            break;
                        case 3:
                            开火 = false;
                            开镜 = false;
                            开火开镜 = true;
                            break;
                        }

                        ImGui::SliderFloat("压枪调节",&Aim_PosZ,0.000,0.015);
                        ImGui::SliderFloat("自瞄速度",&自瞄速度, 1.5,10.0f);

                    }

                    static int a = 1;
                    ImGui::RadioButton("头部", &a, 1);
                    ImGui::SameLine();
                    ImGui::RadioButton("身体", &a, 2);
                    switch (a) {
                    case 1:
                        头部 = true;;
                        身体 = false;
                        break;
                    case 2:
                        头部 = false;
                        身体 = true;
                        break;
                    }

                    ImGui::Checkbox("自动开火", &自动开火);
					ImGui::SameLine();
                    ImGui::Checkbox("智能漏打", &漏打);
                    ImGui::Checkbox("忽略人机", &忽略人坤);
					ImGui::SameLine();
                    ImGui::Checkbox("忽略倒地", &忽略倒地);
                }
            }
            ImGui::EndChild();
        }
        if (ImGui::BeginChild("左侧标题", ImVec2(0, 0), false, ImGuiTabBarFlags_FittingPolicyScroll))
        {
            if(自瞄控件) {
            if (ImGui::CollapsingHeader("基址功能")){							
				ImGui::Checkbox("自改广角", &广角);	
				ImGui::SameLine();			
				ImGui::Checkbox("无后", &枪械无后);
			//	ImGui::SameLine();
				ImGui::Checkbox("防抖", &枪械防抖);
				ImGui::SameLine();
				ImGui::Checkbox("全图变色", &全图变色);				
				if(ImGui::Checkbox("快速切枪",&快速切枪)){
              if(快速切枪 == 1){
快速切枪关 = false;
快速切枪开 = true;
}
if(快速切枪 == 0){
快速切枪开 = false;
快速切枪关 = true;
}}              ImGui::SameLine();
				ImGui::Checkbox("据点", &枪械据点);				
				ImGui::Checkbox("全图除雾", &除雾);
				ImGui::SameLine();		
				if(ImGui::Checkbox("无限子弹",&无限子弹)){
if(无限子弹 == 1){
无限子弹关 = false;
无限子弹开 = true;
}
if(无限子弹 == 0){
无限子弹开 = false;
无限子弹关 = true;
}}
               ImGui::Checkbox("枪械射速", &自改射速);		
               ImGui::SameLine();
				ImGui::Checkbox("打击特效", &旋转变色);	
				ImGui::Checkbox("准心变色", &准心rgb);	
				}
				if (ImGui::CollapsingHeader("全火功能")){	
				ImGui::Checkbox("传送", &传送);
				ImGui::SameLine();
			//	ImGui::Checkbox("热气球过校验", &循环);
			//	ImGui::SameLine();
				ImGui::Checkbox("电梯加速", &电梯);
				//ImGui::SameLine();
			//	ImGui::Checkbox("高跳加速", &加速);
				ImGui::Checkbox("定飞", &定飞);
				//ImGui::Checkbox("hook加速", &地铁加速);
				//ImGui::Checkbox("七图防拉", &七图);
				//ImGui::SameLine();
				//ImGui::Checkbox("不掉定点", &飞天);						
				}					
			if (ImGui::CollapsingHeader("参数调节")){			
			ImGui::SliderFloat("射速调节",&射速调节, 0.000f, 0.150f);
                   ImGui::SliderFloat("广角大小",&广角调节, 1.0f, 3.0f);
                    ImGui::SliderInt("自改推荐=10-15",&加速自改,10,15);
                    ImGui::SliderInt("定飞速度",&定飞自改,13,16);
				
				}
					if (ImGui::CollapsingHeader("函数功能")){		
				ImGui::Checkbox("人物淫叫", &淫叫);
				ImGui::Checkbox("载具自控", &载具自控);	
				if (ImGui::Button("退出对局",ImVec2(120,40)))
				{
					g_LocalPlayer->STPlayerController->ClientInterruptGame();
				}
				
				if (ImGui::Button("对局胜利",ImVec2(120,40)))
				{
					g_LocalPlayer->STPlayerController->RPC_GiveUpGame();
				}
				
				if (ImGui::Button("僵尸来了",ImVec2(120,40)))
				{
					g_LocalPlayer->STPlayerController->ClientShowInfectAreaWarning();
				}
            }
            }
            ImGui::EndChild();
        }



        if (ImGui::BeginChild("左侧标题", ImVec2(0, 0), false, ImGuiTabBarFlags_FittingPolicyScroll))
        {
            if(设置控件)
            {
                ImGui::Checkbox("隐藏TG", &水印);
                static const char* colors[] = {"紫色主题", "蓝色主题", "白色主题","粉色主题"};
                static int selectedColor = 0;
                ImGui::Combo("菜单风格", &selectedColor, colors, IM_ARRAYSIZE(colors));
                switch (selectedColor) {
                case 0:
                    ImGui::StyleColorsClassic();
                    break;
                case 1:
                    ImGui::StyleColorsDark();
                    break;
                case 2:
                    ImGui::StyleColorsLight();
                    break;
                case 3:
                    ImGui::StyleColorsPink();
                    break;
                }
                if (ImGui::Button("保存配置")) {
                    int fd = open("/data/data/com.tencent.igce/liangmo.h", O_WRONLY | O_CREAT, 077);
                    write(fd, &sizeof(Config));
                    close(fd);
                    system("chmod 777 /data/data/com.tencent.igce/liangmo.h");
                }
                ImGui::SameLine();
                if (ImGui::Button("删除配置"))
                {
                    system("rm -rf /data/data/com.tencent.igce/liangmo.h");
                }
                ImGui::Text("自配防封\n@liangmoyyds");
            }
            ImGui::EndChild();
        }



        ImGui::EndChild();

    }







    ImGui::End();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
// ================================================================================================================================ //
    return orig_eglSwapBuffers(dpy, surface);
}


int32_t (*orig_onInputEvent)(struct android_app *app, AInputEvent *inputEvent);

int32_t onInputEvent(struct android_app *app, AInputEvent *inputEvent) {
    if (initImGui) {
        ImGui_ImplAndroid_HandleInputEvent(inputEvent, {(float) screenWidth / (float) glWidth, (float) screenHeight / (float) glHeight});
    }
    return orig_onInputEvent(app, inputEvent);
}

#define PI   3.14159265358979323846f
#define SLEEP_TIME 1000LL / 120LL
#define MEMTRAPS_DELAY 1000LL

[[noreturn]] void *maps_thread(void *) {
    while (true) {
        auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

        std::vector<sRegion> tmp;
        char line[512];
        FILE *f = fopen("/proc/self/maps", "r");
        if (f) {
            while (fgets(line, sizeof line, f)) {
                uintptr_t start, end;
                char tmpProt[16];
                if (sscanf(line, "%" PRIXPTR "-%" PRIXPTR " %16s %*s %*s %*s %*s", &start, &end, tmpProt) > 0) {
                    if (tmpProt[0] != 'r') {
                        tmp.push_back({start, end});
                    }
                }
            }
            fclose(f);
        }
        auto objs = UObject::GetGlobalObjects();
        for (int i = 0; i < objs.Num(); i++) {
            auto Object = objs.GetByIndex(i);
            if (isObjectInvalid(Object))
                continue;
if (除雾) {
if (Object->IsA(UExponentialHeightFogComponent::StaticClass())) {
auto playerChar = (UExponentialHeightFogComponent *) Object;
playerChar->SetFogMaxOpacity(0.0f);
playerChar->SetFogDensity(0.0f);
playerChar->SetFogHeightFalloff(0.0f);
playerChar->SetFogCutoffDistance(0.0f);
playerChar->SetStartDistance(0.0f);
}}

if (全图变色) {
auto objs = UObject::GetGlobalObjects();
        for (int i = 0; i < objs.Num(); i++) {
            auto Object = objs.GetByIndex(i);
         if (isObjectInvalid(Object))
             continue;
if (Object->IsA(UPrimitiveComponent ::StaticClass())) {
auto playerChar = (UPrimitiveComponent  *) Object;    
static float cnt = 0.0f;
float r = cos(cnt) * .5f + .5f;
float g = cos(cnt - 2.f * 3.14 / 3.f) * .5f + .5f;
float b = cos(cnt - 4.f * 3.14 / 3.f) * .5f + .5f;
if (cnt >= FLT_MAX) {
cnt = 0.0f;
} else {
cnt += 0.01f;
}    
playerChar->SetDrawIdeaOutline(true);
playerChar->SetIdeaOutlineNew(true);
playerChar->SetIdeaOutlineOcclusionHighlight(true);
playerChar->OverrideIdeaOutlineThickness(true, 1);      
playerChar->OverrideIdeaOutlineColor(true,FLinearColor(r, g, b, 1.f));
}}}

if (自改射速) {
if (Object->IsA(UShootWeaponEntity::StaticClass())) {
auto NIKESDK = (UShootWeaponEntity *) Object;
NIKESDK->ShootInterval = 射速调节;
}}


if (快速切枪开) {
if (Object->IsA(ASTExtraBaseCharacter::StaticClass())) {
auto PlayerChar = (ASTExtraBaseCharacter *) Object;           
PlayerChar->SwitchWeaponSpeedScale = 1000.0f;
}}

if (快速切枪关) {
if (Object->IsA(ASTExtraBaseCharacter::StaticClass())) {
auto PlayerChar = (ASTExtraBaseCharacter *) Object;           
PlayerChar->SwitchWeaponSpeedScale = 1.0f;
}}

if (枪械防抖) {
auto WeaponManagerComponent = g_LocalPlayer->WeaponManagerComponent;
if (WeaponManagerComponent) {
auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
if (CurrentWeaponReplicated) {
auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
if (ShootWeaponEntityComp && ShootWeaponEffectComp) {

if (枪械防抖) {
ShootWeaponEntityComp->AccessoriesVRecoilFactor = 0.0f;
ShootWeaponEntityComp->AccessoriesHRecoilFactor = 0.0f;
ShootWeaponEntityComp->AccessoriesRecoveryFactor = 0.0f;
}}}}}

if (无限子弹开) {
if (Object->IsA(UShootWeaponEntity::StaticClass())) {
auto PlayerChar = (UShootWeaponEntity *) Object;
PlayerChar->bHasInfiniteClips = true;
PlayerChar->bClipHasInfiniteBullets = true;
}     
if (Object->IsA(ASTExtraShootWeapon::StaticClass())) {
auto PlayerChar = (ASTExtraShootWeapon *) Object;
PlayerChar->CurMaxBulletNumInOneClip = 6969;
}}

if (无限子弹关) {
if (Object->IsA(UShootWeaponEntity::StaticClass())) {
auto PlayerChar = (UShootWeaponEntity *) Object;
PlayerChar->bHasInfiniteClips = false;
PlayerChar->bClipHasInfiniteBullets = false;
}     
if (Object->IsA(ASTExtraShootWeapon::StaticClass())) {
auto PlayerChar = (ASTExtraShootWeapon *) Object;
PlayerChar->CurMaxBulletNumInOneClip = 6969;
}}

if (枪械据点) {
auto WeaponManagerComponent = g_LocalPlayer->WeaponManagerComponent;
if (WeaponManagerComponent) {
auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
if (CurrentWeaponReplicated) {
auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
if (ShootWeaponEntityComp && ShootWeaponEffectComp) {

if (枪械据点) {
ShootWeaponEntityComp->ShotGunVerticalSpread = 0.0f;
ShootWeaponEntityComp->ShotGunHorizontalSpread = 0.0f;
ShootWeaponEntityComp->GameDeviationFactor = 0.0f;
ShootWeaponEntityComp->GameDeviationAccuracy = 0.0f;                                    
ShootWeaponEntityComp->CrossHairInitialSize = 0.0f;
ShootWeaponEntityComp->CrossHairBurstSpeed = 0.0f;
ShootWeaponEntityComp->CrossHairBurstIncreaseSpeed = 0.0f;             
}}}}}



if (枪械无后) {
auto WeaponManagerComponent = g_LocalPlayer->WeaponManagerComponent;
if (WeaponManagerComponent) {
auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
if (CurrentWeaponReplicated) {
auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
if (ShootWeaponEntityComp && ShootWeaponEffectComp) {

if (枪械无后) {
ShootWeaponEffectComp->CameraShakeInnerRadius = 0.0f;
ShootWeaponEffectComp->CameraShakeOuterRadius = 0.0f;
ShootWeaponEffectComp->CameraShakFalloff = 0.0f;
}}}}}

if(载具自控){
if (g_LocalPlayer->CurrentVehicle) {
auto CurrentVehicle = g_LocalPlayer->CurrentVehicle;
auto RootComponent = static_cast<UPrimitiveComponent*>(CurrentVehicle->K2_GetRootComponent());
if (RootComponent) {
 if (g_LocalPlayer->CurrentVehicle->GetMoveForwardRate() > 0) {
FVector 솓도;
auto 야우 = g_LocalController->PlayerCameraManager->CameraCache.POV.Rotation.Yaw;
float 세세 = 2.f * (야우 / 360.f) * M_PI;

솓도.X = (130 /* disired speed*/ * cosf(세세));
솓도.Y = (130 * sinf(세세));

RootComponent->SetAllPhysicsLinearVelocity(솓도, true);
}
}
}
}



		


if (广角) {
Write<float>(UE4+0x2F6A9A8,广角调节);
}


        }
    }
    return 0;
}




void 其他()
{
      写入F类<float>(UE4 + 0x952ABC8F,8.95671814e-21);
                    写入D类(UE4 + 0x703EBF0,-721215457);
                    写入D类(UE4 + 0x703EC0C,-721215457);
                    写入D类(UE4 + 0x703EC8C,-721215457);
                    写入D类(UE4 + 0x75CDA48,-721215457);
                    写入D类(UE4 + 0x75CDAA0,-721215457);
                    写入D类(UE4 + 0x75CDAA8,-721215457);
PATCH_LIB("libUE4.so","0x2283E18","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A01E8","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x2283C20","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A03E0","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x22838D8","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A0728","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x22833EC","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A0C14","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x22831A0","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A0E60","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x2282F00","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A1100","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x2282D08","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A12F8","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x2282A24","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A15DC","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x22828BC","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A1744","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x228277C","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A1884","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x2282740","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A18C0","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x2282320","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A1CE0","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x22822EC","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封
PATCH_LIB("libUE4.so","0x6E4D6A1D14","h C0 03 5F D6 FF FF FF FF");//3.6完美处理追封

PATCH_LIB("libUE4.so","0x3488f88","1F 20 03 D5");
PATCH_LIB("libUE4.so","0x49fab7c","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libUE4.so","0x36b760c","1F 20 03 D5");
PATCH_LIB("libUE4.so","0x4c52614","00 00 80 D2 C0 03 5F D6");

}


void *NIKEHome_thread(void *) {

    while (!UE4Bss) {
        UE4Bss = GetModule(OBFUSCATE("libUE4.so:bss"));
        sleep(1);
    }

    while (!UE4) {
        UE4 = Tools::GetBaseAddress("libUE4.so");
        sleep(1);
    }
    while (!g_App) {
        g_App = *(android_app **) (UE4 + GNativeAndroidApp_Offset);
        sleep(1);
    }

    FName::GNames = GetGNames();
    while (!FName::GNames) {
        FName::GNames = GetGNames();
        sleep(1);
    }
    UObject::GUObjectArray = (FUObjectArray *) (UE4 + GUObject_Offset);

    orig_onInputEvent = decltype(orig_onInputEvent)(g_App->onInputEvent);
    g_App->onInputEvent = onInputEvent;
    void *egl = dlopen_ex("libEGL.so", 4);
    while (!egl) {
        egl = dlopen_ex("libEGL.so", 4);
        sleep(1);
    }
	
	
	
	其他();
	
	thread whthread(MThread);
    whthread.detach();
	
    // #define 渲染函数 0xADD4A40
    A64HookFunction((void *)(UE4+eglSwapBuffers),(void *)_eglSwapBuffers,(void **)&orig_eglSwapBuffers);
    
    pthread_t t;
    pthread_create(&t, 0, maps_thread, 0);
   // pthread_create(&t, 0, 功能线程, 0);  
    return 0;
}


__attribute__((constructor)) void _init() {
    pthread_t t;
    pthread_t ptid;
    pthread_create(&t, 0, NIKEHome_thread, 0);
}
